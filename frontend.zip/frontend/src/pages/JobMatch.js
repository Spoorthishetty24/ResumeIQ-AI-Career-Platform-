import { useState, useEffect } from "react";
import { C, S } from "../theme";
import { PageHeader, Spinner, ErrorBanner, PrimaryBtn, Badge, ProgressBar } from "../components/Shared";
import * as API from "../api";

export default function JobMatch() {
  const [resume,  setResume]  = useState("");
  const [jobs,    setJobs]    = useState([]);
  const [selJob,  setSelJob]  = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");

  useEffect(() => {
    API.getJobs().then(d=>setJobs(d.jobs||[])).catch(()=>{});
  }, []);

  const match = async () => {
    if (!resume.trim()||!selJob) { setError("Resume and job role required."); return; }
    setError(""); setLoading(true); setResults(null);
    try { setResults(await API.matchJob(resume,selJob)); }
    catch(ex){ setError(ex.message); }
    finally { setLoading(false); }
  };

  const pct = results?.match_percent || 0;
  const pctColor = pct>=70?C.green:pct>=50?C.yellow:C.red;

  return (
    <div>
      <PageHeader icon="🎯" title="Job Matching Engine" subtitle="Select a target role and see how well your resume matches with skill gap report"/>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:24,marginBottom:24}}>
        <div style={S.card} className="hcard">
          <div style={S.label}>📋 Your Resume</div>
          <textarea style={{...S.textarea,minHeight:220}} placeholder="Paste your resume here..." value={resume} onChange={e=>setResume(e.target.value)}/>
        </div>

        <div style={S.card} className="hcard">
          <div style={S.label}>🎯 Select Target Job Role</div>
          <div style={{display:"flex",flexDirection:"column",gap:8}}>
            {jobs.map(j=>(
              <div key={j.id} onClick={()=>setSelJob(j.id)} style={{padding:"12px 16px",borderRadius:10,cursor:"pointer",border:`1px solid ${selJob===j.id?C.accent:C.dim}`,background:selJob===j.id?`${C.accent}18`:C.surface,transition:"all .18s"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <div style={{fontSize:13,fontWeight:600,color:selJob===j.id?C.text:C.muted,fontFamily:"'Syne',sans-serif"}}>{j.title}</div>
                  <div style={{display:"flex",gap:6}}>
                    <Badge color={j.growth==="Very High"?C.green:C.yellow}>{j.growth} Growth</Badge>
                    <span style={{fontSize:11,color:C.muted}}>{j.salary}</span>
                  </div>
                </div>
                <div style={{fontSize:11,color:C.dim,marginTop:4}}>{j.skills?.slice(0,4).join(" · ")}{j.skills?.length>4?` +${j.skills.length-4} more`:""}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <ErrorBanner msg={error}/>
      <PrimaryBtn onClick={match} disabled={loading||!selJob} style={{width:"100%",padding:16,fontSize:15,marginBottom:24}}>
        {loading?"⏳ Matching...":"🎯 Calculate Job Match Score"}
      </PrimaryBtn>
      {loading&&<Spinner text="AI is matching your resume to the job role..."/>}

      {results&&!loading&&(
        <div className="fade-in">
          {/* Big match score */}
          <div style={{...S.card,marginBottom:20,textAlign:"center",background:`linear-gradient(135deg,${pctColor}18,transparent)`,borderTop:`3px solid ${pctColor}`}}>
            <div style={{fontSize:12,color:pctColor,fontWeight:600,marginBottom:8,letterSpacing:"0.1em"}}>MATCH SCORE FOR {results.job?.title?.toUpperCase()}</div>
            <div style={{fontSize:64,fontWeight:800,color:pctColor,fontFamily:"'Syne',sans-serif",lineHeight:1}}>{pct}%</div>
            <div style={{maxWidth:500,margin:"12px auto 0",height:10,background:C.dim,borderRadius:5,overflow:"hidden"}}>
              <div style={{height:"100%",width:`${pct}%`,background:`linear-gradient(90deg,${pctColor}88,${pctColor})`,borderRadius:5,transition:"width 1s ease"}}/>
            </div>
            <p style={{fontSize:14,color:C.muted,lineHeight:1.7,marginTop:16,maxWidth:600,margin:"16px auto 0"}}>{results.recommendation}</p>
          </div>

          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:20,marginBottom:20}}>
            {/* Matched skills */}
            <div style={S.card}>
              <div style={{fontSize:11,color:C.green,fontWeight:600,marginBottom:10,letterSpacing:"0.08em"}}>✅ MATCHED SKILLS</div>
              {results.matched_skills?.map(s=>(
                <div key={s} style={{fontSize:13,color:C.text,padding:"5px 0",borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:8}}>
                  <span style={{color:C.green,fontSize:10}}>●</span>{s}
                </div>
              ))}
            </div>

            {/* Missing skills */}
            <div style={S.card}>
              <div style={{fontSize:11,color:C.red,fontWeight:600,marginBottom:10,letterSpacing:"0.08em"}}>❌ MISSING SKILLS</div>
              {results.missing_skills?.map(s=>(
                <div key={s} style={{fontSize:13,color:C.text,padding:"5px 0",borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:8}}>
                  <span style={{color:C.red,fontSize:10}}>●</span>{s}
                </div>
              ))}
            </div>

            {/* Strong/weak points */}
            <div style={S.card}>
              <div style={{fontSize:11,color:C.cyan,fontWeight:600,marginBottom:8,letterSpacing:"0.08em"}}>💪 STRONG POINTS</div>
              {results.strong_points?.map((p,i)=><div key={i} style={{fontSize:12,color:C.muted,padding:"4px 0",borderBottom:`1px solid ${C.border}`}}>▸ {p}</div>)}
              <div style={{fontSize:11,color:C.yellow,fontWeight:600,margin:"12px 0 8px",letterSpacing:"0.08em"}}>⚠️ WEAK AREAS</div>
              {results.weak_points?.map((p,i)=><div key={i} style={{fontSize:12,color:C.muted,padding:"4px 0",borderBottom:`1px solid ${C.border}`}}>▸ {p}</div>)}
            </div>
          </div>

          {/* Learning topics */}
          {results.learning_topics?.length>0&&(
            <div style={S.card}>
              <div style={S.label}>📚 Recommended Learning Topics</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:12}}>
                {results.learning_topics.map((t,i)=>(
                  <div key={i} style={{background:C.surface,borderRadius:10,padding:"14px 16px",border:`1px solid ${t.priority==="high"?C.accent+"44":C.border}`}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
                      <div style={{fontSize:13,fontWeight:600,color:C.text}}>{t.topic}</div>
                      <Badge color={t.priority==="high"?C.accent:C.yellow}>{t.priority}</Badge>
                    </div>
                    <div style={{fontSize:11,color:C.muted}}>📍 {t.resource}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
