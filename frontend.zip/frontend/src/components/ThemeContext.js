import { createContext, useContext, useState } from "react";
import { DARK, LIGHT } from "../theme";

const ThemeContext = createContext();

export function ThemeProvider({ children }) {
  const [isDark, setIsDark] = useState(
    () => localStorage.getItem("riq_theme") !== "light"
  );

  const toggle = () => {
    setIsDark((prev) => {
      localStorage.setItem("riq_theme", prev ? "light" : "dark");
      return !prev;
    });
  };

  const colors = isDark ? DARK : LIGHT;

  return (
    <ThemeContext.Provider value={{ isDark, toggle, colors }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}