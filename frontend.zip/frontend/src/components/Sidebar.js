import { C } from "../theme";
const NAV_USER = [
  {id:"dashboard",  icon:"📊", label:"Dashboard"},
  {id:"analyzer",   icon:"🔍", label:"Resume Analyzer"},
  {id:"insights",   icon:"📈", label:"Visual Insights"},
  {id:"jobmatch",   icon:"🎯", label:"Job Matching"},
  {id:"career",     icon:"🌟", label:"Career AI"},
  {id:"roadmap",    icon:"🗺️",  label:"Learning Roadmap"},
  {id:"interview",  icon:"🎤", label:"Mock Interview"},
  {id:"builder",    icon:"✏️",  label:"Resume Builder"},
  {id:"coverletter",icon:"📝", label:"Cover Letter"},
  {id:"history",    icon:"📋", label:"History"},
  {id:"profile",    icon:"👤", label:"My Profile"},
];
const NAV_RECRUITER = [{id:"dashboard",icon:"📊",label:"Dashboard"},{id:"recruiter",icon:"👨‍💼",label:"Candidates"}];
const NAV_ADMIN     = [{id:"dashboard",icon:"📊",label:"Dashboard"},{id:"admin",icon:"🛠️",label:"Admin Panel"}];

export default function Sidebar({ page, setPage, user, onLogout }) {
  const nav = user?.role==="admin"?NAV_ADMIN:user?.role==="recruiter"?NAV_RECRUITER:NAV_USER;
  const roleColor = user?.role==="admin"?C.red:user?.role==="recruiter"?C.cyan:C.accent;
  return (
    <div style={{width:230,minHeight:"100vh",background:C.surface,borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column",position:"fixed",left:0,top:0,zIndex:100}}>
      <div style={{padding:"22px 18px",borderBottom:`1px solid ${C.border}`}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <div style={{width:36,height:36,borderRadius:10,background:`linear-gradient(135deg,${C.accent},${C.cyan})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,boxShadow:`0 0 16px ${C.glow}`}}>📄</div>
          <div>
            <div style={{fontSize:17,fontWeight:800,fontFamily:"'Syne',sans-serif",background:`linear-gradient(135deg,${C.text},${C.accent})`,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>ResumeIQ</div>
            <div style={{fontSize:9,color:C.muted,letterSpacing:"0.08em"}}>AI CAREER PLATFORM</div>
          </div>
        </div>
      </div>
      <div style={{padding:"8px 18px 8px",borderBottom:`1px solid ${C.border}`}}>
        <span style={{fontSize:10,padding:"3px 10px",borderRadius:20,fontWeight:700,background:`${roleColor}20`,color:roleColor,border:`1px solid ${roleColor}40`,textTransform:"uppercase",letterSpacing:"0.08em"}}>{user?.role||"user"}</span>
      </div>
      <nav style={{flex:1,padding:"10px 10px",overflowY:"auto"}}>
        {nav.map(n=>{
          const active=page===n.id;
          return <div key={n.id} onClick={()=>setPage(n.id)} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 12px",borderRadius:9,cursor:"pointer",marginBottom:2,transition:"all .18s",background:active?`${C.accent}20`:"transparent",border:active?`1px solid ${C.accent}44`:"1px solid transparent",color:active?C.text:C.muted}}>
            <span style={{fontSize:15}}>{n.icon}</span>
            <span style={{fontSize:12,fontWeight:active?600:400,fontFamily:"'Syne',sans-serif"}}>{n.label}</span>
            {active&&<div style={{marginLeft:"auto",width:5,height:5,borderRadius:"50%",background:C.accent,boxShadow:`0 0 8px ${C.accent}`}}/>}
          </div>;
        })}
      </nav>
      <div style={{padding:"14px 18px",borderTop:`1px solid ${C.border}`}}>
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}>
          {user?.photo?<img src={user.photo} alt="av" style={{width:34,height:34,borderRadius:"50%",objectFit:"cover",border:`2px solid ${C.accent}`}}/>
            :<div style={{width:34,height:34,borderRadius:"50%",background:`linear-gradient(135deg,${C.accent},${C.cyan})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,fontWeight:700,color:"#fff",flexShrink:0}}>{user?.name?.[0]?.toUpperCase()||"U"}</div>}
          <div style={{overflow:"hidden"}}>
            <div style={{fontSize:12,color:C.text,fontWeight:600,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{user?.name}</div>
            <div style={{fontSize:10,color:C.muted,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{user?.email}</div>
          </div>
        </div>
        <button onClick={onLogout} style={{width:"100%",padding:"7px",background:"transparent",border:`1px solid ${C.dim}`,borderRadius:8,color:C.muted,fontSize:11,cursor:"pointer",fontFamily:"'DM Mono',monospace"}}>← Logout</button>
      </div>
    </div>
  );
}
