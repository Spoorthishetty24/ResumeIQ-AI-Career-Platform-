import { useState } from "react";
import { PieChart,Pie,Cell,BarChart,Bar,XAxis,YAxis,CartesianGrid,Tooltip,RadarChart,PolarGrid,PolarAngleAxis,Radar,ResponsiveContainer,Legend } from "recharts";
import { C, S } from "../theme";
import { PageHeader, Spinner, ErrorBanner, PrimaryBtn, ScoreRing } from "../components/Shared";
import * as API from "../api";

const COLORS = ["#6c63ff","#00c8ff","#00e5a0","#ffd166","#9b59b6","#ff8c42","#ff6b9d","#ff4d6d"];

export default function Insights() {
  const [resume,  setResume]  = useState("");
  const [jobDesc, setJobDesc] = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");

  const analyze = async () => {
    if (!resume.trim()) { setError("Please paste your resume."); return; }
    setError(""); setLoading(true);
    try { setResults(await API.analyzeResume(resume,jobDesc)); }
    catch(ex){ setError(ex.message); }
    finally { setLoading(false); }
  };

  const skillCatData = results?.skill_categories ? Object.entries(results.skill_categories).map(([name,value])=>({name,value})) : [];
  const techVsSoftData = results ? [
    {name:"Technical",  count:results.technical_skills?.length||0, fill:"#6c63ff"},
    {name:"Soft Skills",count:results.soft_skills?.length||0,      fill:"#00e5a0"},
    {name:"Found",      count:results.skills_found?.length||0,     fill:"#00c8ff"},
    {name:"Missing",    count:results.skills_missing?.length||0,   fill:"#ff4d6d"},
  ] : [];
  const radarData = results ? [
    {subject:"ATS",     A:results.ats_score||0},
    {subject:"Quality", A:results.quality_score||0},
    {subject:"Impact",  A:results.impact_score||0},
    {subject:"Match",   A:results.match_score||50},
    {subject:"Keywords",A:Math.round((results.keywords_matched?.length||0)/((results.keywords_matched?.length||0)+(results.keywords_missing?.length||1))*100)},
  ] : [];

  const tip = {background:"#16161f",border:"1px solid #1e1e2e",borderRadius:16,padding:24};
  const lbl = {fontSize:11,fontWeight:600,letterSpacing:"0.12em",color:"#6c63ff",textTransform:"uppercase",marginBottom:12};

  return (
    <div>
      <PageHeader icon="📈" title="Resume Insights" subtitle="Visual analytics — skill breakdown, ATS metrics and job match charts"/>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:24,marginBottom:24}}>
        <div style={tip} className="hcard">
          <div style={lbl}>📋 Resume</div>
          <textarea style={{...S.textarea,minHeight:200}} placeholder="Paste your resume here..." value={resume} onChange={e=>setResume(e.target.value)}/>
        </div>
        <div style={tip} className="hcard">
          <div style={lbl}>💼 Job Description (optional)</div>
          <textarea style={{...S.textarea,minHeight:200}} placeholder="Paste job description for match charts..." value={jobDesc} onChange={e=>setJobDesc(e.target.value)}/>
        </div>
      </div>
      <ErrorBanner msg={error}/>
      <PrimaryBtn onClick={analyze} disabled={loading} style={{width:"100%",padding:16,fontSize:15,marginBottom:28}}>
        {loading?"⏳ Generating Insights...":"📊 Generate Visual Insights"}
      </PrimaryBtn>
      {loading&&<Spinner text="Building your analytics dashboard..."/>}

      {results&&!loading&&(
        <div className="fade-in">
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:16,marginBottom:28}}>
            <ScoreRing score={results.ats_score}     label="ATS Score" color={results.ats_score>=70?"#00e5a0":results.ats_score>=50?"#ffd166":"#ff4d6d"}/>
            <ScoreRing score={results.quality_score} label="Quality"   color="#00c8ff"/>
            <ScoreRing score={results.impact_score}  label="Impact"    color="#ffd166"/>
            <ScoreRing score={results.match_score??0} label="JD Match" color="#6c63ff"/>
          </div>

          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:24,marginBottom:24}}>
            <div style={tip}>
              <div style={lbl}>🥧 Skill Categories Breakdown</div>
              {skillCatData.length>0?(
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie data={skillCatData} cx="50%" cy="50%" outerRadius={90} dataKey="value" label={({name,percent})=>`${name} ${(percent*100).toFixed(0)}%`} labelLine={true}>
                      {skillCatData.map((_,i)=><Cell key={i} fill={COLORS[i%COLORS.length]}/>)}
                    </Pie>
                    <Tooltip contentStyle={{background:"#16161f",border:"1px solid #1e1e2e",borderRadius:8,color:"#e8e8f0",fontSize:12}}/>
                    <Legend wrapperStyle={{fontSize:11,color:"#6b6b80"}}/>
                  </PieChart>
                </ResponsiveContainer>
              ):<div style={{color:"#6b6b80",textAlign:"center",padding:40}}>No data</div>}
            </div>

            <div style={tip}>
              <div style={lbl}>📊 Technical vs Soft Skills</div>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={techVsSoftData} margin={{top:10,right:10,left:-20,bottom:0}}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#3a3a50"/>
                  <XAxis dataKey="name" tick={{fill:"#6b6b80",fontSize:11}}/>
                  <YAxis tick={{fill:"#6b6b80",fontSize:11}}/>
                  <Tooltip contentStyle={{background:"#16161f",border:"1px solid #1e1e2e",borderRadius:8,color:"#e8e8f0",fontSize:12}}/>
                  <Bar dataKey="count" radius={[6,6,0,0]}>
                    {techVsSoftData.map((entry,i)=><Cell key={i} fill={entry.fill}/>)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div style={tip}>
            <div style={lbl}>🕸️ Resume Performance Radar</div>
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="#3a3a50"/>
                <PolarAngleAxis dataKey="subject" tick={{fill:"#6b6b80",fontSize:12}}/>
                <Radar name="Score" dataKey="A" stroke="#6c63ff" fill="#6c63ff" fillOpacity={0.25} strokeWidth={2}/>
                <Tooltip contentStyle={{background:"#16161f",border:"1px solid #1e1e2e",borderRadius:8,color:"#e8e8f0",fontSize:12}}/>
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20,marginTop:20}}>
            <div style={tip}>
              <div style={{fontSize:11,color:"#00e5a0",fontWeight:600,marginBottom:10}}>SKILLS FOUND ({results.skills_found?.length||0})</div>
              <div>{results.skills_found?.map(s=><span key={s} style={{display:"inline-flex",padding:"4px 10px",borderRadius:6,fontSize:12,margin:"3px",background:"#00e5a015",color:"#00e5a0",border:"1px solid #00e5a030"}}>✓ {s}</span>)}</div>
            </div>
            <div style={tip}>
              <div style={{fontSize:11,color:"#ff4d6d",fontWeight:600,marginBottom:10}}>MISSING SKILLS ({results.skills_missing?.length||0})</div>
              <div>{results.skills_missing?.map(s=><span key={s} style={{display:"inline-flex",padding:"4px 10px",borderRadius:6,fontSize:12,margin:"3px",background:"#ff4d6d15",color:"#ff4d6d",border:"1px solid #ff4d6d30"}}>✗ {s}</span>)}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
