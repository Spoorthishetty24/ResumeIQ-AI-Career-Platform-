import { useState } from "react";
import { C, S } from "../theme";
import { ErrorBanner, SuccessBanner, PrimaryBtn, Spinner } from "../components/Shared";
import * as API from "../api";

const SECTIONS = [
  { id: "summary",     label: "Professional Summary", icon: "👤", placeholder: "Paste or write your professional summary..." },
  { id: "experience",  label: "Work Experience",      icon: "💼", placeholder: "Paste your work experience bullet points..." },
  { id: "skills",      label: "Skills",               icon: "🔧", placeholder: "List your skills here..." },
  { id: "education",   label: "Education",            icon: "🎓", placeholder: "Enter your education details..." },
  { id: "projects",    label: "Projects",             icon: "🚀", placeholder: "Describe your projects..." },
  { id: "achievements",label: "Achievements",         icon: "🏆", placeholder: "List your achievements and awards..." },
];

export default function Builder() {
  const [activeSection, setActiveSection] = useState("summary");
  const [contents,      setContents]      = useState({});
  const [enhanced,      setEnhanced]      = useState({});
  const [loading,       setLoading]       = useState(false);
  const [error,         setError]         = useState("");
  const [success,       setSuccess]       = useState("");
  const [jobTitle,      setJobTitle]      = useState("");

  const section = SECTIONS.find(s => s.id === activeSection);

  const enhance = async () => {
    const content = contents[activeSection];
    if (!content?.trim()) { setError("Please enter content to enhance."); return; }
    setError(""); setLoading(true);
    try {
      const res = await API.enhanceSection(activeSection, content, jobTitle);
      setEnhanced(prev => ({ ...prev, [activeSection]: res.enhanced }));
      setSuccess("✨ Enhanced successfully!");
      setTimeout(() => setSuccess(""), 3000);
    } catch (ex) { setError(ex.message); }
    finally { setLoading(false); }
  };

  const useEnhanced = () => {
    setContents(prev => ({ ...prev, [activeSection]: enhanced[activeSection] }));
    setEnhanced(prev => ({ ...prev, [activeSection]: "" }));
  };

  const copyAll = () => {
    const text = SECTIONS.map(s => contents[s.id] ? `=== ${s.label.toUpperCase()} ===\n${contents[s.id]}` : "").filter(Boolean).join("\n\n");
    navigator.clipboard.writeText(text);
    setSuccess("📋 Copied to clipboard!"); setTimeout(() => setSuccess(""), 3000);
  };

  const completedCount = SECTIONS.filter(s => contents[s.id]?.trim()).length;

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 22, fontWeight: 800, fontFamily: "'Syne',sans-serif", color: C.text }}>✏️ Resume Builder</div>
        <div style={{ fontSize: 13, color: C.muted, marginTop: 4 }}>Write each section and let AI enhance it with powerful, ATS-friendly language</div>
      </div>

      {/* Job title input */}
      <div style={{ ...S.card, marginBottom: 24 }}>
        <div style={S.label}>🎯 Target Job Title (optional — improves AI enhancement)</div>
        <input style={{ ...S.input, maxWidth: 400 }} placeholder="e.g. Senior Frontend Developer" value={jobTitle} onChange={e => setJobTitle(e.target.value)} />
      </div>

      {/* Progress */}
      <div style={{ ...S.card, marginBottom: 24 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div style={{ fontSize: 13, color: C.text, fontWeight: 600 }}>Resume Completion</div>
          <div style={{ fontSize: 13, color: C.accent, fontWeight: 700 }}>{completedCount}/{SECTIONS.length} sections</div>
        </div>
        <div style={{ height: 8, background: C.dim, borderRadius: 4, overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${(completedCount / SECTIONS.length) * 100}%`, background: `linear-gradient(90deg,${C.accent},${C.cyan})`, borderRadius: 4, transition: "width .6s ease" }} />
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 14, flexWrap: "wrap" }}>
          {SECTIONS.map(s => (
            <div key={s.id} onClick={() => setActiveSection(s.id)} style={{
              padding: "6px 14px", borderRadius: 20, cursor: "pointer", fontSize: 12, fontWeight: 600,
              border: `1px solid ${activeSection === s.id ? C.accent : contents[s.id]?.trim() ? C.green : C.dim}`,
              background: activeSection === s.id ? `${C.accent}22` : contents[s.id]?.trim() ? `${C.green}15` : "transparent",
              color: activeSection === s.id ? C.accent : contents[s.id]?.trim() ? C.green : C.muted,
            }}>{s.icon} {s.label} {contents[s.id]?.trim() ? "✓" : ""}</div>
          ))}
        </div>
      </div>

      {/* Section editor */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <div style={S.card}>
          <div style={S.label}>{section.icon} {section.label}</div>
          <textarea
            style={{ ...S.textarea, minHeight: 280 }}
            placeholder={section.placeholder}
            value={contents[activeSection] || ""}
            onChange={e => setContents(prev => ({ ...prev, [activeSection]: e.target.value }))}
          />
          <div style={{ fontSize: 11, color: C.muted, marginTop: 6, marginBottom: 16 }}>
            {contents[activeSection] ? `${contents[activeSection].split(/\s+/).filter(Boolean).length} words` : "Write your content above"}
          </div>
          <ErrorBanner msg={error} />
          <SuccessBanner msg={success} />
          <PrimaryBtn onClick={enhance} disabled={loading} style={{ width: "100%" }}>
            {loading ? "⏳ Enhancing..." : "✨ Enhance with AI"}
          </PrimaryBtn>
        </div>

        <div style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <div style={S.label}>🚀 AI Enhanced Version</div>
            {enhanced[activeSection] && (
              <button onClick={useEnhanced} style={{ padding: "5px 14px", background: `${C.green}22`, border: `1px solid ${C.green}44`, borderRadius: 8, color: C.green, fontSize: 11, cursor: "pointer", fontFamily: "'DM Mono',monospace", fontWeight: 600 }}>
                ← Use This
              </button>
            )}
          </div>
          {loading ? <Spinner text="AI is enhancing your content..." /> :
            enhanced[activeSection] ? (
              <div style={{ background: C.surface, borderRadius: 10, padding: 16, fontSize: 13, color: C.text, lineHeight: 1.8, minHeight: 280, whiteSpace: "pre-wrap", border: `1px solid ${C.green}33` }}>
                {enhanced[activeSection]}
              </div>
            ) : (
              <div style={{ minHeight: 280, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: C.dim, fontSize: 13, gap: 12 }}>
                <div style={{ fontSize: 40 }}>✨</div>
                <div>Enhanced content will appear here</div>
                <div style={{ fontSize: 11, color: C.dim, textAlign: "center" }}>Write your content on the left and click "Enhance with AI"</div>
              </div>
            )}
        </div>
      </div>

      {/* Copy all button */}
      {completedCount > 0 && (
        <div style={{ marginTop: 24, textAlign: "center" }}>
          <button onClick={copyAll} style={{ padding: "12px 32px", background: `${C.cyan}22`, border: `1px solid ${C.cyan}44`, borderRadius: 11, color: C.cyan, fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'Syne',sans-serif" }}>
            📋 Copy Full Resume to Clipboard
          </button>
        </div>
      )}
    </div>
  );
}
