import { useState } from "react";
import { C, S } from "../theme";
import * as API from "../api";

export default function Profile({ user, onUserUpdate }) {
  const [name,setName]=useState(user?.name||"");const [bio,setBio]=useState(user?.bio||"");const [phone,setPhone]=useState(user?.phone||"");const [location,setLocation]=useState(user?.location||"");const [saving,setSaving]=useState(false);const [success,setSuccess]=useState("");const [error,setError]=useState("");const [uploading,setUploading]=useState(false);const [resName,setResName]=useState("");const [resText,setResText]=useState("");const [savingRes,setSavingRes]=useState(false);const [resumes,setResumes]=useState(user?.resumes||[]);

  const saveProfile=async()=>{setSaving(true);setError("");setSuccess("");try{const u=await API.updateProfile({name,bio,phone,location});onUserUpdate(u);setSuccess("Profile updated!");setTimeout(()=>setSuccess(""),3000);}catch(ex){setError(ex.message);}finally{setSaving(false);}};
  const uploadPhoto=async(e)=>{const f=e.target.files?.[0];if(!f)return;setUploading(true);try{const d=await API.uploadPhoto(f);onUserUpdate({...user,photo:d.photo});setSuccess("Photo updated!");setTimeout(()=>setSuccess(""),3000);}catch(ex){setError(ex.message);}finally{setUploading(false);};};
  const addResume=async()=>{if(!resText.trim())return;setSavingRes(true);try{const r=await API.saveResume(resName||`Resume ${resumes.length+1}`,resText);setResumes(prev=>[...prev,r]);setResName("");setResText("");setSuccess("Resume saved!");setTimeout(()=>setSuccess(""),3000);}catch(ex){setError(ex.message);}finally{setSavingRes(false);}};
  const removeResume=async(id)=>{try{await API.deleteResume(id);setResumes(prev=>prev.filter(r=>r.id!==id));}catch(ex){setError(ex.message);}};

  return(
    <div>
      <div style={{marginBottom:28}}><div style={{fontSize:24,fontWeight:800,fontFamily:"'Syne',sans-serif",color:C.text}}>👤 My Profile</div><div style={{fontSize:13,color:C.muted,marginTop:5}}>Manage your details, profile photo and saved resumes</div></div>
      {error&&<div style={{background:"#ff4d6d18",border:"1px solid #ff4d6d44",borderRadius:10,padding:"12px 18px",color:C.red,fontSize:13,marginBottom:16}}>⚠️ {error}</div>}
      {success&&<div style={{background:"#00e5a018",border:"1px solid #00e5a044",borderRadius:10,padding:"12px 18px",color:C.green,fontSize:13,marginBottom:16}}>✅ {success}</div>}
      <div style={{display:"grid",gridTemplateColumns:"260px 1fr",gap:24,marginBottom:24}}>
        <div style={S.card}>
          <div style={{textAlign:"center",marginBottom:16}}>
            <div style={{position:"relative",display:"inline-block"}}>
              {user?.photo?<img src={user.photo} alt="av" style={{width:90,height:90,borderRadius:"50%",objectFit:"cover",border:`3px solid ${C.accent}`}}/>
                :<div style={{width:90,height:90,borderRadius:"50%",background:`linear-gradient(135deg,${C.accent},${C.cyan})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:32,fontWeight:700,color:"#fff",margin:"0 auto"}}>{user?.name?.[0]?.toUpperCase()||"U"}</div>}
              <label style={{position:"absolute",bottom:0,right:0,width:26,height:26,borderRadius:"50%",background:C.accent,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",fontSize:12}}>
                {uploading?"⏳":"📷"}<input type="file" accept="image/*" style={{display:"none"}} onChange={uploadPhoto}/>
              </label>
            </div>
            <div style={{fontSize:15,fontWeight:700,color:C.text,marginTop:10,fontFamily:"'Syne',sans-serif"}}>{user?.name}</div>
            <div style={{fontSize:11,color:C.muted}}>{user?.email}</div>
            <div style={{marginTop:8,padding:"3px 12px",borderRadius:20,display:"inline-block",fontSize:11,fontWeight:600,background:`${C.accent}20`,color:C.accent}}>{user?.role?.toUpperCase()}</div>
          </div>
        </div>
        <div style={S.card}>
          <div style={{fontSize:11,fontWeight:600,color:C.accent,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:14}}>✏️ Edit Details</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <div><label style={{fontSize:11,color:C.muted,display:"block",marginBottom:4}}>FULL NAME</label><input style={S.input} value={name} onChange={e=>setName(e.target.value)}/></div>
            <div><label style={{fontSize:11,color:C.muted,display:"block",marginBottom:4}}>PHONE</label><input style={S.input} placeholder="+91 XXXXX XXXXX" value={phone} onChange={e=>setPhone(e.target.value)}/></div>
            <div><label style={{fontSize:11,color:C.muted,display:"block",marginBottom:4}}>LOCATION</label><input style={S.input} placeholder="City, Country" value={location} onChange={e=>setLocation(e.target.value)}/></div>
          </div>
          <div style={{marginTop:12}}><label style={{fontSize:11,color:C.muted,display:"block",marginBottom:4}}>BIO</label><textarea style={{...S.textarea,minHeight:70}} placeholder="Short professional bio..." value={bio} onChange={e=>setBio(e.target.value)}/></div>
          <button onClick={saveProfile} disabled={saving} style={{marginTop:14,padding:"10px 22px",background:`linear-gradient(135deg,${C.accent},#9b59b6)`,border:"none",borderRadius:10,color:"#fff",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"'Syne',sans-serif"}}>{saving?"⏳ Saving...":"💾 Save Profile"}</button>
        </div>
      </div>
      <div style={S.card}>
        <div style={{fontSize:11,fontWeight:600,color:C.accent,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:14}}>📄 Saved Resumes ({resumes.length})</div>
        {resumes.length>0&&<div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:16}}>{resumes.map(r=><div key={r.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",background:C.surface,borderRadius:8,padding:"10px 14px",border:`1px solid ${C.border}`}}><div><div style={{fontSize:13,fontWeight:600,color:C.text}}>{r.name}</div><div style={{fontSize:10,color:C.muted,marginTop:2}}>{r.text?.split(/\s+/).filter(Boolean).length} words · {new Date(r.createdAt).toLocaleDateString()}</div></div><button onClick={()=>removeResume(r.id)} style={{padding:"4px 10px",background:"#ff4d6d18",border:"1px solid #ff4d6d40",borderRadius:6,color:C.red,fontSize:11,cursor:"pointer"}}>🗑️</button></div>)}</div>}
        <div style={{borderTop:`1px solid ${C.border}`,paddingTop:14}}>
          <div style={{fontSize:11,color:C.muted,fontWeight:600,marginBottom:8}}>ADD NEW RESUME</div>
          <input style={{...S.input,marginBottom:8}} placeholder="Resume name..." value={resName} onChange={e=>setResName(e.target.value)}/>
          <textarea style={{...S.textarea,minHeight:100}} placeholder="Paste resume text..." value={resText} onChange={e=>setResText(e.target.value)}/>
          <button onClick={addResume} disabled={savingRes||!resText.trim()} style={{marginTop:8,padding:"8px 18px",background:`${C.green}22`,border:`1px solid ${C.green}44`,borderRadius:8,color:C.green,fontSize:12,fontWeight:600,cursor:"pointer",fontFamily:"'Syne',sans-serif"}}>{savingRes?"⏳ Saving...":"+ Save Resume"}</button>
        </div>
      </div>
    </div>
  );
}
