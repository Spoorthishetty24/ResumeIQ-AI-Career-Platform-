import { useState, useEffect } from "react";
import { C, S } from "../theme";
import { PageHeader, Spinner, Badge, ProgressBar } from "../components/Shared";
import * as API from "../api";

export default function RecruiterDashboard() {
  const [candidates, setCandidates] = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [search,     setSearch]     = useState("");
  const [sortBy,     setSortBy]     = useState("ats");
  const [expanded,   setExpanded]   = useState(null);

  useEffect(() => {
    API.getCandidates().then(d=>{setCandidates(d.candidates||[]);setLoading(false);}).catch(()=>setLoading(false));
  }, []);

  const filtered = candidates
    .filter(c => {
      if (!search) return true;
      return c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.email.toLowerCase().includes(search.toLowerCase()) ||
        c.latestSkills?.some(s=>s.toLowerCase().includes(search.toLowerCase()));
    })
    .sort((a,b)=>{
      if (sortBy==="ats")   return (b.latestAtsScore||0)-(a.latestAtsScore||0);
      if (sortBy==="name")  return a.name.localeCompare(b.name);
      if (sortBy==="analyses") return b.totalAnalyses-a.totalAnalyses;
      return 0;
    });

  if (loading) return <Spinner text="Loading candidates..."/>;

  return (
    <div>
      <PageHeader icon="👨‍💼" title="Recruiter Dashboard" subtitle="Browse candidates, filter by skills and view ATS scores"/>

      {/* Stats */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16,marginBottom:24}}>
        {[
          {icon:"👥",value:candidates.length,label:"Total Candidates",color:C.accent},
          {icon:"📊",value:candidates.filter(c=>c.latestAtsScore>=70).length,label:"High ATS Score (70+)",color:C.green},
          {icon:"🔍",value:candidates.filter(c=>c.totalAnalyses>0).length,label:"Analyzed Resumes",color:C.cyan},
        ].map(s=>(
          <div key={s.label} style={{...S.card,textAlign:"center"}}>
            <div style={{fontSize:28,marginBottom:6}}>{s.icon}</div>
            <div style={{fontSize:28,fontWeight:800,color:s.color,fontFamily:"'Syne',sans-serif"}}>{s.value}</div>
            <div style={{fontSize:12,color:C.muted,marginTop:4}}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div style={{...S.card,marginBottom:20}}>
        <div style={{display:"flex",gap:12,flexWrap:"wrap",alignItems:"center"}}>
          <input style={{...S.input,maxWidth:280,padding:"9px 14px"}} placeholder="🔍 Search by name, email or skill..." value={search} onChange={e=>setSearch(e.target.value)}/>
          <div style={{display:"flex",gap:8,alignItems:"center"}}>
            <span style={{fontSize:12,color:C.muted}}>Sort by:</span>
            {[{v:"ats",l:"ATS Score"},{v:"name",l:"Name"},{v:"analyses",l:"Analyses"}].map(s=>(
              <button key={s.v} onClick={()=>setSortBy(s.v)} style={{padding:"6px 14px",borderRadius:20,border:`1px solid ${sortBy===s.v?C.accent:C.dim}`,background:sortBy===s.v?`${C.accent}22`:"transparent",color:sortBy===s.v?C.accent:C.muted,fontSize:11,fontWeight:600,cursor:"pointer"}}>
                {s.l}
              </button>
            ))}
          </div>
        </div>
      </div>

      {candidates.length===0?(
        <div style={{textAlign:"center",padding:60,opacity:.5}}>
          <div style={{fontSize:48,marginBottom:12}}>👥</div>
          <div style={{fontSize:16,color:C.muted,fontFamily:"'Syne',sans-serif"}}>No candidates yet</div>
          <div style={{fontSize:13,color:C.dim,marginTop:6}}>Candidates appear here after they sign up and analyze resumes</div>
        </div>
      ):(
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          {filtered.map((c,i)=>(
            <div key={c.id} style={S.card} className="hcard">
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:12,flexWrap:"wrap"}}>
                <div style={{display:"flex",alignItems:"center",gap:12}}>
                  <div style={{width:42,height:42,borderRadius:"50%",background:`linear-gradient(135deg,${C.accent},${C.cyan})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,fontWeight:700,color:"#fff",flexShrink:0}}>
                    {c.name?.[0]?.toUpperCase()||"?"}
                  </div>
                  <div>
                    <div style={{fontSize:14,fontWeight:700,color:C.text,fontFamily:"'Syne',sans-serif"}}>{c.name}</div>
                    <div style={{fontSize:11,color:C.muted}}>{c.email} · {c.location||"Location N/A"}</div>
                    <div style={{fontSize:11,color:C.muted,marginTop:2}}>{c.bio||"No bio added"}</div>
                  </div>
                </div>
                <div style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap"}}>
                  {c.latestAtsScore!=null&&(
                    <div style={{textAlign:"center",padding:"8px 14px",borderRadius:10,background:c.latestAtsScore>=70?`${C.green}18`:c.latestAtsScore>=50?`${C.yellow}18`:`${C.red}18`,border:`1px solid ${c.latestAtsScore>=70?C.green:c.latestAtsScore>=50?C.yellow:C.red}33`}}>
                      <div style={{fontSize:18,fontWeight:800,color:c.latestAtsScore>=70?C.green:c.latestAtsScore>=50?C.yellow:C.red,fontFamily:"'Syne',sans-serif"}}>{c.latestAtsScore}</div>
                      <div style={{fontSize:9,color:C.muted,textTransform:"uppercase"}}>ATS Score</div>
                    </div>
                  )}
                  <Badge color={C.muted}>{c.totalAnalyses} analyses</Badge>
                  <button onClick={()=>setExpanded(expanded===i?null:i)} style={{padding:"6px 14px",background:`${C.accent}18`,border:`1px solid ${C.accent}40`,borderRadius:8,color:C.accent,fontSize:11,cursor:"pointer",fontFamily:"'DM Mono',monospace"}}>
                    {expanded===i?"▲ Hide":"▼ Details"}
                  </button>
                </div>
              </div>

              {/* Skills */}
              {c.latestSkills?.length>0&&(
                <div style={{marginTop:10,display:"flex",flexWrap:"wrap",gap:4}}>
                  {c.latestSkills.slice(0,8).map(s=><span key={s} style={{padding:"3px 8px",borderRadius:5,fontSize:10,background:`${C.accent}15`,color:C.accent,border:`1px solid ${C.accent}30`}}>{s}</span>)}
                  {c.latestSkills.length>8&&<span style={{fontSize:10,color:C.dim,padding:"3px 8px"}}>+{c.latestSkills.length-8} more</span>}
                </div>
              )}

              {expanded===i&&(
                <div className="fade-in" style={{marginTop:14,paddingTop:14,borderTop:`1px solid ${C.border}`}}>
                  <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
                    {[
                      {label:"Total Analyses",value:c.totalAnalyses,color:C.accent},
                      {label:"ATS Score",value:c.latestAtsScore!=null?`${c.latestAtsScore}/100`:"N/A",color:C.green},
                      {label:"Member Since",value:new Date(c.createdAt).toLocaleDateString(),color:C.cyan},
                    ].map(item=>(
                      <div key={item.label} style={{background:C.surface,borderRadius:8,padding:"10px 14px",textAlign:"center"}}>
                        <div style={{fontSize:16,fontWeight:700,color:item.color,fontFamily:"'Syne',sans-serif"}}>{item.value}</div>
                        <div style={{fontSize:10,color:C.muted,marginTop:2}}>{item.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
