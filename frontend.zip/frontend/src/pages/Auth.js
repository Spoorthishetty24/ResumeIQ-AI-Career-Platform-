import { useState } from "react";
import { C, S } from "../theme";
import * as API from "../api";
export default function AuthPage({ onAuth, onBack }) {
  const [mode,setMode]=useState("login");const [name,setName]=useState("");const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [role,setRole]=useState("user");const [showPass,setShowPass]=useState(false);const [err,setErr]=useState("");const [ok,setOk]=useState("");const [busy,setBusy]=useState(false);
  const validate=()=>{if(!email.trim()||!password.trim())return"Email and password required.";if(!/\S+@\S+\.\S+/.test(email))return"Invalid email.";if(password.length<6)return"Password must be 6+ chars.";if(mode==="signup"&&!name.trim())return"Name required.";return null;};
  const submit=async()=>{setErr("");setOk("");const e=validate();if(e){setErr(e);return;}setBusy(true);try{let data;if(mode==="signup"){data=await API.register(name.trim(),email.trim(),password,role);setOk("Account created!");}else{data=await API.login(email.trim(),password);}sessionStorage.setItem("riq_token",data.token);setTimeout(()=>onAuth(data.user),500);}catch(ex){setErr(ex.message);}finally{setBusy(false);}};
  return(
    <div style={{minHeight:"100vh",background:C.bg,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'DM Mono',monospace",position:"relative",overflow:"hidden"}}>
      <div style={{position:"absolute",width:600,height:600,borderRadius:"50%",background:`radial-gradient(circle,${C.accent}12,transparent 70%)`,top:-200,left:-200,pointerEvents:"none"}}/>
      <div className="auth-in" style={{width:"100%",maxWidth:460,background:C.card,border:`1px solid ${C.border}`,borderRadius:24,padding:"42px 40px",position:"relative",zIndex:1,boxShadow:"0 24px 80px #00000080"}}>
        <button onClick={onBack} style={{position:"absolute",top:18,left:18,background:"none",border:"none",color:C.muted,cursor:"pointer",fontSize:20}}>←</button>
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",marginBottom:28}}>
          <div style={{width:60,height:60,borderRadius:16,background:`linear-gradient(135deg,${C.accent},${C.cyan})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:30,boxShadow:`0 0 32px ${C.glow}`,marginBottom:14}}>📄</div>
          <div style={{fontSize:28,fontWeight:800,fontFamily:"'Syne',sans-serif",background:`linear-gradient(135deg,${C.text},${C.accent})`,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>ResumeIQ</div>
          <div style={{fontSize:11,color:C.muted,marginTop:5}}>AI Career Platform</div>
        </div>
        <div style={{display:"flex",background:C.surface,borderRadius:12,padding:4,marginBottom:24,border:`1px solid ${C.dim}`}}>
          {["login","signup"].map(m=><button key={m} onClick={()=>{setMode(m);setErr("");setOk("");}} style={{flex:1,padding:"9px",borderRadius:9,border:"none",cursor:"pointer",fontSize:12,fontWeight:700,letterSpacing:"0.06em",textTransform:"uppercase",fontFamily:"'Syne',sans-serif",background:mode===m?`linear-gradient(135deg,${C.accent},#9b59b6)`:"transparent",color:mode===m?"#fff":C.muted}}>{m==="login"?"🔐 Sign In":"✨ Sign Up"}</button>)}
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:13}}>
          {mode==="signup"&&<><div><label style={{fontSize:11,color:C.muted,display:"block",marginBottom:5}}>FULL NAME</label><input style={S.input} placeholder="John Doe" value={name} onChange={e=>setName(e.target.value)}/></div>
          <div><label style={{fontSize:11,color:C.muted,display:"block",marginBottom:5}}>SIGN UP AS</label><div style={{display:"flex",gap:8}}>{["user","recruiter"].map(r=><button key={r} onClick={()=>setRole(r)} style={{flex:1,padding:"9px",borderRadius:9,border:`1px solid ${role===r?C.accent:C.dim}`,cursor:"pointer",fontSize:12,fontWeight:600,textTransform:"capitalize",fontFamily:"'Syne',sans-serif",background:role===r?`${C.accent}22`:"transparent",color:role===r?C.accent:C.muted}}>{r==="user"?"👤 Job Seeker":"👨‍💼 Recruiter"}</button>)}</div></div></>}
          <div><label style={{fontSize:11,color:C.muted,display:"block",marginBottom:5}}>EMAIL</label><input style={S.input} type="email" placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)}/></div>
          <div><label style={{fontSize:11,color:C.muted,display:"block",marginBottom:5}}>PASSWORD</label><div style={{position:"relative"}}><input style={{...S.input,paddingRight:44}} type={showPass?"text":"password"} placeholder="••••••••" value={password} onChange={e=>setPassword(e.target.value)} onKeyDown={e=>e.key==="Enter"&&submit()}/><button onClick={()=>setShowPass(p=>!p)} style={{position:"absolute",right:12,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",cursor:"pointer",color:C.muted,fontSize:16}}>{showPass?"🙈":"👁️"}</button></div></div>
        </div>
        {err&&<div style={{marginTop:12,padding:"10px 14px",background:"#ff4d6d18",border:"1px solid #ff4d6d40",borderRadius:8,color:C.red,fontSize:12}}>⚠️ {err}</div>}
        {ok &&<div style={{marginTop:12,padding:"10px 14px",background:"#00e5a018",border:"1px solid #00e5a040",borderRadius:8,color:C.green,fontSize:12}}>✅ {ok}</div>}
        <button onClick={submit} disabled={busy} style={{width:"100%",marginTop:20,padding:"14px",background:`linear-gradient(135deg,${C.accent},#9b59b6)`,border:"none",borderRadius:11,color:"#fff",fontSize:14,fontWeight:700,fontFamily:"'Syne',sans-serif",cursor:"pointer",boxShadow:`0 4px 24px ${C.glow}`,opacity:busy?0.7:1}}>{busy?"⏳ Please wait...":mode==="login"?"Sign In →":"Create Account →"}</button>
        <div style={{textAlign:"center",marginTop:16,fontSize:12,color:C.muted}}>{mode==="login"?"No account? ":"Already registered? "}<span onClick={()=>{setMode(mode==="login"?"signup":"login");setErr("");setOk("");}} style={{color:C.accent,cursor:"pointer",fontWeight:600}}>{mode==="login"?"Sign Up free":"Sign In"}</span></div>
        <div style={{textAlign:"center",marginTop:10,fontSize:10,color:C.dim}}>Admin: admin@resumeiq.com / admin123</div>
      </div>
    </div>
  );
}
