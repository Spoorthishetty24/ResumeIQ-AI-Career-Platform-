import { useState, useEffect } from "react";
import { C, S } from "../theme";
import { ScoreRing, Spinner, Badge } from "../components/Shared";
import * as API from "../api";

export default function History({ setPage }) {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);
  const [deleting, setDeleting] = useState(null);

  useEffect(() => {
    API.getHistory().then(d => { setHistory(d.history || []); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const del = async (id) => {
    setDeleting(id);
    try { await API.deleteHistory(id); setHistory(h => h.filter(x => x.id !== id)); }
    catch {}
    finally { setDeleting(null); }
  };

  if (loading) return <Spinner text="Loading history..." />;

  return (
    <div>
      <div style={{ marginBottom: 24, display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
        <div>
          <div style={{ fontSize: 22, fontWeight: 800, fontFamily: "'Syne',sans-serif", color: C.text }}>📋 Analysis History</div>
          <div style={{ fontSize: 13, color: C.muted, marginTop: 4 }}>Track your resume improvement over time</div>
        </div>
        {history.length > 0 && (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <span style={{ fontSize: 12, color: C.muted }}>Analyses stored:</span>
              <span style={{ fontSize: 13, fontWeight: 700, color: history.length >= 10 ? C.yellow : C.green }}>{history.length} / 10</span>
            </div>
            <div style={{ width: 160, height: 6, background: C.dim, borderRadius: 3, overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${(history.length / 10) * 100}%`, background: history.length >= 10 ? `linear-gradient(90deg,${C.yellow},${C.orange})` : `linear-gradient(90deg,${C.green},${C.cyan})`, borderRadius: 3, transition: "width .6s ease" }} />
            </div>
            {history.length >= 10 && <div style={{ fontSize: 11, color: C.yellow }}>⚠️ Limit reached — oldest will be replaced</div>}
          </div>
        )}
      </div>

      {history.length === 0 ? (
        <div style={{ textAlign: "center", padding: "80px 20px", opacity: 0.5 }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>📋</div>
          <div style={{ fontSize: 16, color: C.muted, fontFamily: "'Syne',sans-serif" }}>No analyses yet</div>
          <div style={{ fontSize: 13, color: C.dim, marginTop: 8 }}>Go to Resume Analyzer to get started</div>
          <button onClick={() => setPage("analyzer")} style={{ marginTop: 20, padding: "10px 24px", background: `linear-gradient(135deg,${C.accent},#9b59b6)`, border: "none", borderRadius: 10, color: "#fff", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "'Syne',sans-serif" }}>
            🔍 Analyze Resume
          </button>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {history.map((h, i) => (
            <div key={h.id} style={S.card} className="hcard">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16 }}>
                <div style={{ flex: 1, cursor: "pointer" }} onClick={() => setExpanded(expanded === i ? null : i)}>
                  <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 8, flexWrap: "wrap" }}>
                    <Badge color={h.ats_score >= 70 ? C.green : h.ats_score >= 50 ? C.yellow : C.red}>ATS {h.ats_score}</Badge>
                    <Badge color={C.cyan}>Quality {h.quality_score}</Badge>
                    <Badge color={C.yellow}>Impact {h.impact_score}</Badge>
                    {h.match_score != null && <Badge color={C.accent}>Match {h.match_score}%</Badge>}
                    {h.jobDescription && <Badge color={C.purple}>With JD</Badge>}
                    <span style={{ fontSize: 11, color: C.dim }}>🕐 {new Date(h.date).toLocaleString()}</span>
                  </div>
                  <div style={{ fontSize: 13, color: C.muted, lineHeight: 1.6 }}>{h.summary}</div>
                </div>
                <div style={{ display: "flex", gap: 8, flexShrink: 0 }}>
                  <button onClick={() => setExpanded(expanded === i ? null : i)} style={{ padding: "6px 12px", background: `${C.accent}18`, border: `1px solid ${C.accent}40`, borderRadius: 8, color: C.accent, fontSize: 11, cursor: "pointer" }}>
                    {expanded === i ? "▲ Hide" : "▼ View"}
                  </button>
                  <button onClick={() => del(h.id)} disabled={deleting === h.id} style={{ padding: "6px 12px", background: "#ff4d6d18", border: "1px solid #ff4d6d40", borderRadius: 8, color: C.red, fontSize: 11, cursor: "pointer" }}>
                    {deleting === h.id ? "..." : "🗑️"}
                  </button>
                </div>
              </div>

              {expanded === i && (
                <div className="fade-in" style={{ marginTop: 20, paddingTop: 20, borderTop: `1px solid ${C.border}` }}>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 20 }}>
                    <ScoreRing score={h.ats_score}     label="ATS"     color={h.ats_score >= 70 ? C.green : h.ats_score >= 50 ? C.yellow : C.red} />
                    <ScoreRing score={h.quality_score} label="Quality" color={C.cyan} />
                    <ScoreRing score={h.match_score ?? 0} label="Match" color={C.accent} />
                    <ScoreRing score={h.impact_score}  label="Impact"  color={C.yellow} />
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                    <div>
                      <div style={{ fontSize: 11, color: C.green, fontWeight: 600, marginBottom: 8 }}>✅ STRENGTHS</div>
                      {h.strengths?.map((s, j) => <div key={j} style={{ fontSize: 13, color: C.text, padding: "5px 0", borderBottom: `1px solid ${C.border}` }}><span style={{ color: C.green }}>▸</span> {s}</div>)}
                    </div>
                    <div>
                      <div style={{ fontSize: 11, color: C.red, fontWeight: 600, marginBottom: 8 }}>⚠️ TOP ISSUES</div>
                      {h.improvements?.slice(0, 3).map((imp, j) => <div key={j} style={{ fontSize: 12, color: C.muted, padding: "5px 0", borderBottom: `1px solid ${C.border}`, lineHeight: 1.5 }}>• {imp.issue}</div>)}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
