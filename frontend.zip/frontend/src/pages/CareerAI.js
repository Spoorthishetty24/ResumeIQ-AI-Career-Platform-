import { useState } from "react";
import { C, S } from "../theme";
import { PageHeader, Spinner, ErrorBanner, PrimaryBtn, Badge, ProgressBar } from "../components/Shared";
import * as API from "../api";

export default function CareerAI() {
  const [resume,  setResume]  = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");

  const recommend = async () => {
    if (!resume.trim()) { setError("Please paste your resume."); return; }
    setError(""); setLoading(true); setResults(null);
    try { setResults(await API.getCareerRec(resume)); }
    catch(ex){ setError(ex.message); }
    finally { setLoading(false); }
  };

  const growthColor = g => g==="Very High"?C.green:g==="High"?C.cyan:C.yellow;

  return (
    <div>
      <PageHeader icon="🌟" title="AI Career Recommendation" subtitle="Based on your skills, experience and education — find your best-fit roles"/>
      <div style={S.card} className="hcard">
        <div style={S.label}>📋 Your Resume</div>
        <textarea style={{...S.textarea,minHeight:200}} placeholder="Paste your full resume for career analysis..." value={resume} onChange={e=>setResume(e.target.value)}/>
      </div>
      <ErrorBanner msg={error}/>
      <PrimaryBtn onClick={recommend} disabled={loading} style={{width:"100%",padding:16,fontSize:15,margin:"16px 0 24px"}}>
        {loading?"⏳ Analyzing Career Fit...":"🌟 Get AI Career Recommendations"}
      </PrimaryBtn>
      {loading&&<Spinner text="AI is analyzing your career profile..."/>}

      {results&&!loading&&(
        <div className="fade-in">
          {/* Profile summary */}
          <div style={{...S.card,marginBottom:24,background:`linear-gradient(135deg,${C.accent}12,${C.cyan}08)`,borderTop:`3px solid ${C.accent}`}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:12,marginBottom:16}}>
              <div>
                <div style={{fontSize:11,color:C.accent,fontWeight:600,marginBottom:4,letterSpacing:"0.1em"}}>YOUR CAREER PROFILE</div>
                <div style={{fontSize:20,fontWeight:800,fontFamily:"'Syne',sans-serif",color:C.text}}>{results.current_level} Professional</div>
              </div>
              <Badge color={C.green}>{results.current_level}</Badge>
            </div>
            <p style={{fontSize:14,color:C.text,lineHeight:1.7,margin:"0 0 12px"}}>{results.overall_profile}</p>
            <div style={{padding:"10px 14px",background:`${C.cyan}12`,border:`1px solid ${C.cyan}30`,borderRadius:8,fontSize:13,color:C.text}}>
              🎯 <strong style={{color:C.cyan}}>Next Step:</strong> {results.next_step}
            </div>
          </div>

          {/* Top roles */}
          <div style={S.label}>🏆 Top Recommended Roles</div>
          <div style={{display:"flex",flexDirection:"column",gap:16,marginBottom:24}}>
            {results.top_roles?.map((role,i)=>(
              <div key={i} style={{...S.card,borderLeft:`4px solid ${i===0?C.accent:i===1?C.cyan:C.green}`}} className="hcard">
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:12,marginBottom:12}}>
                  <div style={{display:"flex",alignItems:"center",gap:12}}>
                    <div style={{width:36,height:36,borderRadius:10,background:i===0?`${C.accent}22`:i===1?`${C.cyan}22`:`${C.green}22`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,fontWeight:700,color:i===0?C.accent:i===1?C.cyan:C.green,fontFamily:"'Syne',sans-serif"}}>#{i+1}</div>
                    <div>
                      <div style={{fontSize:16,fontWeight:700,fontFamily:"'Syne',sans-serif",color:C.text}}>{role.role}</div>
                      <div style={{fontSize:12,color:C.muted,marginTop:2}}>{role.salary_range}</div>
                    </div>
                  </div>
                  <div style={{display:"flex",gap:8,alignItems:"center"}}>
                    <Badge color={growthColor(role.growth)}>{role.growth} Growth</Badge>
                    <div style={{fontSize:22,fontWeight:800,color:role.match_percent>=70?C.green:role.match_percent>=50?C.yellow:C.red,fontFamily:"'Syne',sans-serif"}}>{role.match_percent}%</div>
                  </div>
                </div>
                <div style={{marginBottom:10}}>
                  <ProgressBar value={role.match_percent} color={role.match_percent>=70?C.green:role.match_percent>=50?C.yellow:C.red}/>
                </div>
                <div style={{fontSize:13,color:C.muted,lineHeight:1.6}}>{role.reason}</div>
              </div>
            ))}
          </div>

          {/* Strengths */}
          <div style={{...S.card,background:`${C.green}08`,border:`1px solid ${C.green}22`}}>
            <div style={{fontSize:11,color:C.green,fontWeight:600,marginBottom:8,letterSpacing:"0.1em"}}>💪 YOUR STANDOUT STRENGTHS</div>
            <div style={{fontSize:14,color:C.text,lineHeight:1.7}}>{results.strengths_summary}</div>
          </div>
        </div>
      )}
    </div>
  );
}
