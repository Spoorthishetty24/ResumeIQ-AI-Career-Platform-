import { useState, useCallback, useRef } from "react";
import { C, S } from "../theme";
import { ScoreRing, SkillPill, Spinner, ErrorBanner, PrimaryBtn, ProgressBar } from "../components/Shared";
import * as API from "../api";

export default function Analyzer() {
  const [resume,       setResume]       = useState("");
  const [jobDesc,      setJobDesc]      = useState("");
  const [results,      setResults]      = useState(null);
  const [loading,      setLoading]      = useState(false);
  const [error,        setError]        = useState("");
  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploadMode,   setUploadMode]   = useState("paste");
  const [dragOver,     setDragOver]     = useState(false);
  const [parsing,      setParsing]      = useState(false);
  const fileRef = useRef(null);

  const parseFile = useCallback(async (file) => {
    setParsing(true); setError("");
    try {
      const ext = file.name.split(".").pop().toLowerCase();
      if (ext === "txt") { setResume(await file.text()); setUploadedFile(file); }
      else if (ext === "pdf") {
        if (!window.pdfjsLib) {
          await new Promise((res, rej) => { const s = document.createElement("script"); s.src = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
          window.pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
        }
        const pdf = await window.pdfjsLib.getDocument({ data: await file.arrayBuffer() }).promise;
        let text = "";
        for (let i = 1; i <= pdf.numPages; i++) { const p = await pdf.getPage(i); const c = await p.getTextContent(); text += c.items.map(x => x.str).join(" ") + "\n"; }
        setResume(text.trim()); setUploadedFile(file);
      } else if (ext === "docx") {
        if (!window.mammoth) { await new Promise((res, rej) => { const s = document.createElement("script"); s.src = "https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js"; s.onload = res; s.onerror = rej; document.head.appendChild(s); }); }
        const result = await window.mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
        setResume(result.value.trim()); setUploadedFile(file);
      } else { setError("Upload PDF, DOCX or TXT only."); }
    } catch { setError("Failed to parse file. Try pasting text."); }
    finally { setParsing(false); }
  }, []);

  const onDrop  = useCallback(e => { e.preventDefault(); setDragOver(false); const f = e.dataTransfer?.files?.[0]; if (f) parseFile(f); }, [parseFile]);
  const onInput = useCallback(e => { const f = e.target.files?.[0]; if (f) parseFile(f); }, [parseFile]);

  const analyze = async () => {
    if (!resume.trim()) { setError("Please add your resume first."); return; }
    setError(""); setLoading(true); setResults(null);
    try { setResults(await API.analyzeResume(resume, jobDesc)); }
    catch (ex) { setError(ex.message); }
    finally { setLoading(false); }
  };

  const priColor = p => p === "high" ? C.red : p === "medium" ? C.yellow : C.green;
  const priBg    = p => p === "high" ? "#ff4d6d18" : p === "medium" ? "#ffd16618" : "#00e5a018";

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 22, fontWeight: 800, fontFamily: "'Syne',sans-serif", color: C.text }}>🔍 Resume Analyzer</div>
        <div style={{ fontSize: 13, color: C.muted, marginTop: 4 }}>Upload your resume and get instant AI-powered ATS scoring & feedback</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 24 }}>
        {/* Resume input */}
        <div style={S.card} className="hcard">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <div style={S.label}><span>📋</span> Your Resume</div>
            <div style={{ display: "flex", background: C.surface, borderRadius: 8, padding: 3, border: `1px solid ${C.dim}` }}>
              {["paste","upload"].map(m => (
                <button key={m} onClick={() => setUploadMode(m)} style={{ padding: "4px 14px", borderRadius: 6, border: "none", cursor: "pointer", fontSize: 11, fontWeight: 600, textTransform: "uppercase", fontFamily: "'DM Mono',monospace", background: uploadMode === m ? C.accent : "transparent", color: uploadMode === m ? "#fff" : C.muted }}>
                  {m === "paste" ? "✏️ Paste" : "📁 Upload"}
                </button>
              ))}
            </div>
          </div>
          {uploadMode === "paste" ? (
            <><textarea style={{ ...S.textarea, minHeight: 220 }} placeholder={"Paste your full resume here...\n\nInclude: experience, skills, education..."} value={resume} onChange={e => setResume(e.target.value)} /><div style={{ fontSize: 11, color: C.muted, marginTop: 6 }}>{resume ? `${resume.split(/\s+/).filter(Boolean).length} words` : "Paste text above"}</div></>
          ) : (
            <>
              <input ref={fileRef} type="file" accept=".pdf,.docx,.txt" style={{ display: "none" }} onChange={onInput} />
              <div onDragOver={e => { e.preventDefault(); setDragOver(true); }} onDragLeave={() => setDragOver(false)} onDrop={onDrop} onClick={() => fileRef.current?.click()}
                style={{ minHeight: 180, border: `2px dashed ${dragOver ? C.accent : C.dim}`, borderRadius: 12, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", cursor: "pointer", background: dragOver ? `${C.accent}0a` : C.surface, gap: 10, padding: 20 }}>
                {parsing ? <><div style={S.spinner} /><div style={{ fontSize: 13, color: C.muted }}>Parsing...</div></> :
                  uploadedFile && resume ? (<><div style={{ fontSize: 36 }}>✅</div><div style={{ fontSize: 13, color: C.green, fontWeight: 600 }}>{uploadedFile.name}</div><div style={{ fontSize: 11, color: C.muted }}>{resume.split(/\s+/).filter(Boolean).length} words</div><button onClick={e => { e.stopPropagation(); setUploadedFile(null); setResume(""); }} style={{ padding: "4px 12px", background: "#ff4d6d20", border: "1px solid #ff4d6d44", borderRadius: 6, color: C.red, fontSize: 11, cursor: "pointer" }}>✕ Remove</button></>) :
                  (<><div style={{ fontSize: 40 }}>📄</div><div style={{ fontSize: 14, color: C.text, fontWeight: 600, fontFamily: "'Syne',sans-serif" }}>{dragOver ? "Drop here!" : "Drag & drop or click"}</div><div style={{ fontSize: 11, color: C.muted }}>PDF · DOCX · TXT</div></>)}
              </div>
            </>
          )}
        </div>

        {/* Job description */}
        <div style={S.card} className="hcard">
          <div style={S.label}><span>💼</span> Job Description <span style={{ color: C.muted, fontWeight: 400, fontSize: 10, textTransform: "none", letterSpacing: 0 }}>(optional)</span></div>
          <textarea style={{ ...S.textarea, minHeight: 220 }} placeholder={"Paste job description for match scoring...\n\nEnables keyword matching and JD score."} value={jobDesc} onChange={e => setJobDesc(e.target.value)} />
          <div style={{ fontSize: 11, color: C.muted, marginTop: 6 }}>{jobDesc ? `${jobDesc.split(/\s+/).filter(Boolean).length} words · Match enabled` : "Add JD for match scoring"}</div>
        </div>
      </div>

      <ErrorBanner msg={error} />

      <PrimaryBtn onClick={analyze} disabled={loading} style={{ width: "100%", padding: 16, fontSize: 15 }}>
        {loading ? "⏳ Analyzing..." : "🔍 Analyze Resume with AI"}
      </PrimaryBtn>

      {loading && <Spinner text="AI is analyzing your resume..." />}

      {results && !loading && (
        <div className="fade-in">
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, margin: "28px 0 24px" }}>
            <ScoreRing score={results.ats_score}     label="ATS Score"     color={results.ats_score >= 70 ? C.green : results.ats_score >= 50 ? C.yellow : C.red} />
            <ScoreRing score={results.quality_score} label="Quality"       color={C.cyan} />
            <ScoreRing score={results.match_score ?? 0} label={results.match_score != null ? "JD Match" : "No JD"} color={C.accent} />
            <ScoreRing score={results.impact_score}  label="Impact"        color={C.yellow} />
          </div>

          <div style={{ ...S.card, marginBottom: 20 }}>
            <div style={S.sectionTitle}>📊 Assessment</div>
            <p style={{ fontSize: 14, lineHeight: 1.7, color: C.text, margin: "0 0 20px" }}>{results.summary}</p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              <div>
                <div style={{ fontSize: 11, color: C.green, fontWeight: 600, marginBottom: 8 }}>✅ STRENGTHS</div>
                {results.strengths?.map((s, i) => <div key={i} style={{ fontSize: 13, color: C.text, padding: "6px 0", borderBottom: `1px solid ${C.border}` }}><span style={{ color: C.green }}>▸</span> {s}</div>)}
              </div>
              <div>
                <div style={{ fontSize: 11, color: C.cyan, fontWeight: 600, marginBottom: 8 }}>🎯 ATS TIPS</div>
                {results.ats_tips?.map((t, i) => <div key={i} style={{ fontSize: 13, color: C.text, padding: "6px 0", borderBottom: `1px solid ${C.border}` }}><span style={{ color: C.cyan }}>▸</span> {t}</div>)}
              </div>
            </div>
          </div>

          <div style={{ ...S.card, marginBottom: 20 }}>
            <div style={S.sectionTitle}>🛠️ Improvements</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {results.improvements?.map((imp, i) => (
                <div key={i} style={{ background: priBg(imp.priority), border: `1px solid ${priColor(imp.priority)}30`, borderLeft: `3px solid ${priColor(imp.priority)}`, borderRadius: 10, padding: "14px 16px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                    <span style={{ fontSize: 13, fontWeight: 600, color: C.text }}>{imp.issue}</span>
                    <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 10, fontWeight: 600, background: `${priColor(imp.priority)}20`, color: priColor(imp.priority), textTransform: "uppercase" }}>{imp.priority}</span>
                  </div>
                  <div style={{ fontSize: 12, color: C.muted, lineHeight: 1.5 }}>💡 {imp.suggestion}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            <div style={S.card}>
              <div style={S.sectionTitle}>🔧 Skills</div>
              <div style={{ marginBottom: 12 }}><div style={{ fontSize: 11, color: C.green, fontWeight: 600, marginBottom: 6 }}>FOUND</div><div>{results.skills_found?.map(s => <SkillPill key={s} skill={s} found={true} />)}</div></div>
              <div><div style={{ fontSize: 11, color: C.red, fontWeight: 600, marginBottom: 6 }}>MISSING</div><div>{results.skills_missing?.map(s => <SkillPill key={s} skill={s} found={false} />)}</div></div>
            </div>
            <div style={S.card}>
              <div style={S.sectionTitle}>🔑 Keywords</div>
              <div style={{ marginBottom: 12 }}><div style={{ fontSize: 11, color: C.green, fontWeight: 600, marginBottom: 6 }}>MATCHED</div><div>{results.keywords_matched?.map(k => <span key={k} style={{ ...S.tag, background: "#00e5a015", color: C.green, border: "1px solid #00e5a030" }}>✓ {k}</span>)}</div></div>
              <div><div style={{ fontSize: 11, color: C.yellow, fontWeight: 600, marginBottom: 6 }}>ADD THESE</div><div>{results.keywords_missing?.map(k => <span key={k} style={{ ...S.tag, background: "#ffd16618", color: C.yellow, border: "1px solid #ffd16630" }}>+ {k}</span>)}</div></div>
              <div style={{ marginTop: 16 }}>
                {[{ label: "ATS", val: results.ats_score, color: C.green }, { label: "Quality", val: results.quality_score, color: C.cyan }, { label: "Impact", val: results.impact_score, color: C.yellow }].map(({ label, val, color }) => (
                  <div key={label} style={{ marginBottom: 10 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: C.muted, marginBottom: 4 }}><span>{label}</span><span style={{ color }}>{val}%</span></div>
                    <ProgressBar value={val} color={color} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
