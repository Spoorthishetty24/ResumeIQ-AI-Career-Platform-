import { useState, useRef, useEffect } from "react";
import { C } from "../theme";

const BOT_AVATAR = "🤖";
const USER_AVATAR = "🧑‍💻";

const WELCOME = {
  role: "assistant",
  text: "Hey there! 👋 I'm **Aria**, your AI career assistant.\n\nI can help you with:\n• 📄 Resume tips & feedback\n• 💼 Career advice & role guidance\n• 🎤 Interview prep & mock questions\n• 🧭 Platform navigation\n\nWhat can I help you with today?",
  time: new Date(),
};

function formatTime(d) {
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function TypingDots() {
  return (
    <div style={{ display: "flex", gap: 5, alignItems: "center", padding: "4px 0" }}>
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          style={{
            width: 8, height: 8, borderRadius: "50%",
            background: C.accent,
            animation: `typingBounce 1.2s ease-in-out ${i * 0.2}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

function MessageBubble({ msg }) {
  const isUser = msg.role === "user";
  const lines = msg.text.split("\n");

  const renderText = (text) => {
    return text.split(/\*\*(.*?)\*\*/g).map((part, i) =>
      i % 2 === 1
        ? <strong key={i} style={{ color: C.accent }}>{part}</strong>
        : part
    );
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: isUser ? "row-reverse" : "row",
        alignItems: "flex-end",
        gap: 10,
        marginBottom: 16,
        animation: "msgSlideIn 0.3s ease forwards",
      }}
    >
      {/* Avatar */}
      <div
        style={{
          width: 36, height: 36, borderRadius: "50%",
          background: isUser
            ? "linear-gradient(135deg, #6c63ff, #9b59b6)"
            : "linear-gradient(135deg, #00c8ff, #00e5a0)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 18, flexShrink: 0,
          boxShadow: isUser
            ? "0 0 12px #6c63ff55"
            : "0 0 12px #00c8ff55",
        }}
      >
        {isUser ? USER_AVATAR : BOT_AVATAR}
      </div>

      {/* Bubble */}
      <div style={{ maxWidth: "75%", display: "flex", flexDirection: "column", alignItems: isUser ? "flex-end" : "flex-start" }}>
        <div
          style={{
            background: isUser
              ? "linear-gradient(135deg, #6c63ff, #5a52e8)"
              : "#1e1e2e",
            border: isUser ? "none" : "1px solid #2a2a40",
            borderRadius: isUser ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
            padding: "12px 16px",
            fontSize: 13,
            lineHeight: 1.6,
            color: C.text,
            boxShadow: isUser
              ? "0 4px 20px #6c63ff33"
              : "0 4px 16px #00000040",
          }}
        >
          {lines.map((line, i) => (
            <div key={i} style={{ marginBottom: i < lines.length - 1 && line ? 4 : 0 }}>
              {line.startsWith("•") ? (
                <div style={{ display: "flex", gap: 6, alignItems: "flex-start" }}>
                  <span style={{ color: C.accent, marginTop: 1 }}>•</span>
                  <span>{renderText(line.slice(1).trim())}</span>
                </div>
              ) : (
                <span>{renderText(line)}</span>
              )}
            </div>
          ))}
        </div>
        <span style={{ fontSize: 10, color: C.muted, marginTop: 4, paddingInline: 4 }}>
          {formatTime(msg.time)}
        </span>
      </div>
    </div>
  );
}

const QUICK_PROMPTS = [
  "💡 Resume tips",
  "🎤 Interview prep",
  "💼 Career advice",
  "📊 ATS score help",
];

export default function AIAssistant() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([WELCOME]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [unread, setUnread] = useState(0);
  const [pulse, setPulse] = useState(true);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (open) {
      setUnread(0);
      setTimeout(() => inputRef.current?.focus(), 200);
    }
  }, [open]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // Pulse animation on FAB
  useEffect(() => {
    const t = setTimeout(() => setPulse(false), 4000);
    return () => clearTimeout(t);
  }, []);

  async function sendMessage(text) {
    const userText = (text || input).trim();
    if (!userText) return;
    setInput("");

    const userMsg = { role: "user", text: userText, time: new Date() };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      const token = sessionStorage.getItem("riq_token");
      const res = await fetch("/api/assistant/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          messages: [...messages, userMsg].map((m) => ({
            role: m.role === "user" ? "user" : "assistant",
            content: m.text,
          })),
        }),
      });
      const data = await res.json();
      const reply = data.reply || "Sorry, I couldn't get a response. Please try again.";
      setMessages((prev) => [...prev, { role: "assistant", text: reply, time: new Date() }]);
      if (!open) setUnread((n) => n + 1);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", text: "⚠️ Connection error. Make sure the backend is running.", time: new Date() },
      ]);
    } finally {
      setLoading(false);
    }
  }

  function handleKey(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  return (
    <>
      <style>{`
        @keyframes typingBounce {
          0%, 60%, 100% { transform: translateY(0); opacity: 0.5; }
          30% { transform: translateY(-8px); opacity: 1; }
        }
        @keyframes msgSlideIn {
          from { opacity: 0; transform: translateY(10px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes fabPulse {
          0%   { box-shadow: 0 0 0 0 #6c63ff88; }
          70%  { box-shadow: 0 0 0 18px #6c63ff00; }
          100% { box-shadow: 0 0 0 0 #6c63ff00; }
        }
        @keyframes chatOpen {
          from { opacity: 0; transform: scale(0.9) translateY(20px); }
          to   { opacity: 1; transform: scale(1) translateY(0); }
        }
        @keyframes ariaGlow {
          0%, 100% { box-shadow: 0 0 20px #00c8ff44, 0 0 40px #00c8ff22; }
          50%       { box-shadow: 0 0 30px #6c63ff66, 0 0 60px #6c63ff33; }
        }
        .ai-fab:hover { transform: scale(1.08) !important; }
        .ai-send:hover { background: #5a52e8 !important; }
        .quick-chip:hover { background: #2a2a45 !important; border-color: #6c63ff !important; transform: translateY(-1px); }
      `}</style>

      {/* Floating Action Button */}
      <button
        className="ai-fab"
        onClick={() => setOpen((o) => !o)}
        style={{
          position: "fixed", bottom: 28, right: 28, zIndex: 9999,
          width: 60, height: 60, borderRadius: "50%", border: "none",
          background: "linear-gradient(135deg, #6c63ff, #00c8ff)",
          cursor: "pointer", fontSize: 26,
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 8px 32px #6c63ff55",
          transition: "transform 0.2s",
          animation: pulse ? "fabPulse 1.5s ease-out 2" : "none",
        }}
        title="AI Career Assistant"
      >
        {open ? "✕" : "🤖"}
        {unread > 0 && !open && (
          <div style={{
            position: "absolute", top: -4, right: -4,
            background: C.red, borderRadius: "50%",
            width: 20, height: 20, fontSize: 11, fontWeight: 700,
            display: "flex", alignItems: "center", justifyContent: "center",
            color: "#fff", border: "2px solid #0a0a0f",
          }}>
            {unread}
          </div>
        )}
      </button>

      {/* Chat Window */}
      {open && (
        <div
          style={{
            position: "fixed", bottom: 100, right: 28, zIndex: 9998,
            width: 380, height: 560,
            background: "#0e0e18",
            border: "1px solid #2a2a40",
            borderRadius: 20,
            boxShadow: "0 24px 80px #00000088, 0 0 0 1px #6c63ff22",
            display: "flex", flexDirection: "column",
            overflow: "hidden",
            animation: "chatOpen 0.3s ease forwards",
          }}
        >
          {/* Header */}
          <div style={{
            background: "linear-gradient(135deg, #16161f, #1a1a2e)",
            borderBottom: "1px solid #2a2a40",
            padding: "16px 20px",
            display: "flex", alignItems: "center", gap: 14,
            flexShrink: 0,
          }}>
            <div style={{
              width: 44, height: 44, borderRadius: "50%",
              background: "linear-gradient(135deg, #00c8ff, #6c63ff)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 22, flexShrink: 0,
              animation: "ariaGlow 2.5s ease-in-out infinite",
            }}>
              🤖
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 15, color: C.text, fontFamily: "'Syne', sans-serif" }}>
                Aria
              </div>
              <div style={{ fontSize: 11, color: C.green, display: "flex", alignItems: "center", gap: 5 }}>
                <div style={{ width: 6, height: 6, borderRadius: "50%", background: C.green, animation: "fabPulse 2s infinite" }} />
                AI Career Assistant • Online
              </div>
            </div>
            <button
              onClick={() => setMessages([WELCOME])}
              title="Clear chat"
              style={{
                background: "none", border: "1px solid #2a2a40", borderRadius: 8,
                color: C.muted, cursor: "pointer", padding: "5px 10px", fontSize: 11,
              }}
            >
              🗑 Clear
            </button>
          </div>

          {/* Messages */}
          <div style={{
            flex: 1, overflowY: "auto", padding: "16px 16px 8px",
            display: "flex", flexDirection: "column",
          }}>
            {messages.map((msg, i) => (
              <MessageBubble key={i} msg={msg} />
            ))}
            {loading && (
              <div style={{ display: "flex", alignItems: "flex-end", gap: 10, marginBottom: 16 }}>
                <div style={{
                  width: 36, height: 36, borderRadius: "50%",
                  background: "linear-gradient(135deg, #00c8ff, #00e5a0)",
                  display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18,
                }}>
                  🤖
                </div>
                <div style={{
                  background: "#1e1e2e", border: "1px solid #2a2a40",
                  borderRadius: "18px 18px 18px 4px", padding: "12px 16px",
                }}>
                  <TypingDots />
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Quick prompts */}
          <div style={{
            padding: "8px 12px",
            display: "flex", gap: 6, flexWrap: "wrap",
            borderTop: "1px solid #1e1e2e",
            background: "#0e0e18",
          }}>
            {QUICK_PROMPTS.map((q) => (
              <button
                key={q}
                className="quick-chip"
                onClick={() => sendMessage(q)}
                disabled={loading}
                style={{
                  background: "#16161f", border: "1px solid #2a2a40",
                  borderRadius: 20, padding: "5px 12px", fontSize: 11,
                  color: C.text, cursor: "pointer", transition: "all 0.2s",
                  fontFamily: "'DM Mono', monospace",
                }}
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input */}
          <div style={{
            padding: "12px 16px",
            borderTop: "1px solid #2a2a40",
            display: "flex", gap: 10, alignItems: "flex-end",
            background: "#0e0e18", flexShrink: 0,
          }}>
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKey}
              placeholder="Ask me anything about your career..."
              rows={1}
              style={{
                flex: 1, background: "#16161f", border: "1px solid #2a2a40",
                borderRadius: 12, color: C.text, padding: "10px 14px",
                fontSize: 13, fontFamily: "'DM Mono', monospace",
                resize: "none", outline: "none", lineHeight: 1.5,
                maxHeight: 100, overflowY: "auto",
                transition: "border-color 0.2s",
              }}
              onFocus={(e) => e.target.style.borderColor = C.accent}
              onBlur={(e) => e.target.style.borderColor = "#2a2a40"}
            />
            <button
              className="ai-send"
              onClick={() => sendMessage()}
              disabled={!input.trim() || loading}
              style={{
                background: C.accent, border: "none", borderRadius: 12,
                width: 42, height: 42, cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 18, flexShrink: 0, transition: "background 0.2s",
                opacity: !input.trim() || loading ? 0.5 : 1,
              }}
            >
              ➤
            </button>
          </div>
        </div>
      )}
    </>
  );
}