import { useState, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { C, S } from "../theme";
import { PageHeader, Spinner, Badge, ErrorBanner, SuccessBanner } from "../components/Shared";
import * as API from "../api";

const COLORS = ["#6c63ff","#00c8ff","#00e5a0","#ffd166","#9b59b6","#ff8c42","#ff6b9d","#ff4d6d","#00e5a0","#ffd166"];

export default function AdminPanel() {
  const [data,     setData]     = useState(null);
  const [loading,  setLoading]  = useState(true);
  const [newJob,   setNewJob]   = useState({title:"",skills:"",salary:"",growth:"High"});
  const [adding,   setAdding]   = useState(false);
  const [error,    setError]    = useState("");
  const [success,  setSuccess]  = useState("");

  const load = () => {
    setLoading(true);
    // ✅ FIXED: clear error on success, show real error on fail
    API.getAdminAnalytics()
      .then(d => { setData(d); setLoading(false); setError(""); })
      .catch(e => { setLoading(false); setError(e.message); });
  };

  useEffect(()=>load(),[]);

  const addJob = async () => {
    if (!newJob.title||!newJob.skills) { setError("Title and skills required."); return; }
    setAdding(true); setError(""); setSuccess("");
    try {
      await API.addJob({...newJob,skills:newJob.skills.split(",").map(s=>s.trim()).filter(Boolean)});
      setSuccess("Job role added!"); setNewJob({title:"",skills:"",salary:"",growth:"High"}); load();
      setTimeout(()=>setSuccess(""),3000);
    } catch(ex){ setError(ex.message); }
    finally { setAdding(false); }
  };

  const removeJob = async (id) => {
    try { await API.deleteJob(id); setSuccess("Job deleted."); load(); setTimeout(()=>setSuccess(""),3000); }
    catch(ex){ setError(ex.message); }
  };

  if (loading) return <Spinner text="Loading admin analytics..."/>;

  const skillGapChart = data?.topSkillGaps?.map((s,i)=>({name:s.skill,count:s.count,fill:COLORS[i%COLORS.length]})) || [];

  return (
    <div>
      <PageHeader icon="🛠️" title="Admin Panel" subtitle="Platform analytics, job role management and skill gap monitoring"/>
      <ErrorBanner msg={error}/><SuccessBanner msg={success}/>

      {/* Platform stats */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:16,marginBottom:24}}>
        {[
          {icon:"📄",v:data?.totalResumes||0,            l:"Total Resumes Analyzed", c:C.accent},
          {icon:"👥",v:data?.totalUsers||0,               l:"Registered Users",       c:C.cyan},
          {icon:"👤",v:data?.usersByRole?.user||0,        l:"Job Seekers",            c:C.green},
          {icon:"👨‍💼",v:data?.usersByRole?.recruiter||0, l:"Recruiters",             c:C.yellow},
        ].map(s=>(
          <div key={s.l} style={{...S.card,textAlign:"center"}}>
            <div style={{fontSize:26,marginBottom:6}}>{s.icon}</div>
            <div style={{fontSize:26,fontWeight:800,color:s.c,fontFamily:"'Syne',sans-serif"}}>{s.v}</div>
            <div style={{fontSize:11,color:C.muted,marginTop:4}}>{s.l}</div>
          </div>
        ))}
      </div>

      {/* Skill gap chart */}
      {skillGapChart.length>0&&(
        <div style={{...S.card,marginBottom:24}}>
          <div style={S.label}>📊 Most Common Skill Gaps (Platform-wide)</div>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={skillGapChart} margin={{top:10,right:10,left:-20,bottom:40}}>
              <CartesianGrid strokeDasharray="3 3" stroke={C.dim}/>
              <XAxis dataKey="name" tick={{fill:C.muted,fontSize:10}} angle={-30} textAnchor="end"/>
              <YAxis tick={{fill:C.muted,fontSize:11}}/>
              <Tooltip contentStyle={{background:C.card,border:`1px solid ${C.border}`,borderRadius:8,color:C.text,fontSize:12}}/>
              <Bar dataKey="count" radius={[6,6,0,0]}>
                {skillGapChart.map((entry,i)=><Cell key={i} fill={entry.fill}/>)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Job management */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:24,marginBottom:24}}>
        {/* Add job */}
        <div style={S.card}>
          <div style={S.label}>➕ Add New Job Role</div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <div>
              <label style={{fontSize:11,color:C.muted,display:"block",marginBottom:4}}>JOB TITLE</label>
              <input style={S.input} placeholder="e.g. React Developer" value={newJob.title} onChange={e=>setNewJob(p=>({...p,title:e.target.value}))}/>
            </div>
            <div>
              <label style={{fontSize:11,color:C.muted,display:"block",marginBottom:4}}>REQUIRED SKILLS (comma-separated)</label>
              <input style={S.input} placeholder="React, JavaScript, CSS, REST API" value={newJob.skills} onChange={e=>setNewJob(p=>({...p,skills:e.target.value}))}/>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              <div>
                <label style={{fontSize:11,color:C.muted,display:"block",marginBottom:4}}>SALARY RANGE</label>
                <input style={S.input} placeholder="Rs6-12 LPA" value={newJob.salary} onChange={e=>setNewJob(p=>({...p,salary:e.target.value}))}/>
              </div>
              <div>
                <label style={{fontSize:11,color:C.muted,display:"block",marginBottom:4}}>GROWTH</label>
                <select style={{...S.input}} value={newJob.growth} onChange={e=>setNewJob(p=>({...p,growth:e.target.value}))}>
                  {["High","Very High","Medium","Low"].map(g=><option key={g} value={g}>{g}</option>)}
                </select>
              </div>
            </div>
            <button onClick={addJob} disabled={adding} style={{padding:"10px",background:`linear-gradient(135deg,${C.accent},#9b59b6)`,border:"none",borderRadius:9,color:"#fff",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"'Syne',sans-serif",opacity:adding?0.6:1}}>
              {adding?"⏳ Adding...":"+ Add Job Role"}
            </button>
          </div>
        </div>

        {/* Existing jobs */}
        <div style={S.card}>
          <div style={S.label}>📋 Job Roles ({data?.jobs?.length||0})</div>
          <div style={{display:"flex",flexDirection:"column",gap:8,maxHeight:360,overflowY:"auto"}}>
            {data?.jobs?.map(j=>(
              <div key={j.id} style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",background:C.surface,borderRadius:8,padding:"10px 14px",border:`1px solid ${C.border}`}}>
                <div>
                  <div style={{fontSize:13,fontWeight:600,color:C.text,fontFamily:"'Syne',sans-serif"}}>{j.title}</div>
                  {/* ✅ FIXED: safely render salary as string */}
                  <div style={{fontSize:10,color:C.muted,marginTop:3}}>
                    {j.skills?.slice(0,3).join(", ")}{j.skills?.length>3?` +${j.skills.length-3}`:""} · {typeof j.salary === "object" ? `Rs${j.salary?.min}-${j.salary?.max} LPA` : j.salary}
                  </div>
                </div>
                <button onClick={()=>removeJob(j.id)} style={{padding:"4px 10px",background:"#ff4d6d18",border:"1px solid #ff4d6d40",borderRadius:6,color:C.red,fontSize:10,cursor:"pointer",flexShrink:0}}>🗑️</button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent users */}
      <div style={S.card}>
        <div style={S.label}>👥 Recent Users</div>
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {data?.recentUsers?.map(u=>(
            <div key={u.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",background:C.surface,borderRadius:8,padding:"10px 14px",border:`1px solid ${C.border}`}}>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <div style={{width:30,height:30,borderRadius:"50%",background:`linear-gradient(135deg,${C.accent},${C.cyan})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:700,color:"#fff"}}>{u.name?.[0]?.toUpperCase()}</div>
                <div>
                  <div style={{fontSize:13,color:C.text,fontWeight:600}}>{u.name}</div>
                  <div style={{fontSize:10,color:C.muted}}>{u.email}</div>
                </div>
              </div>
              <div style={{display:"flex",gap:8,alignItems:"center"}}>
                <Badge color={u.role==="admin"?C.red:u.role==="recruiter"?C.cyan:C.accent}>{u.role}</Badge>
                <span style={{fontSize:10,color:C.dim}}>{new Date(u.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}