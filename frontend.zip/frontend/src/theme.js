export const DARK = {
  bg:"#0a0a0f", surface:"#111118", card:"#16161f", border:"#1e1e2e",
  accent:"#6c63ff", glow:"#6c63ff33", green:"#00e5a0", yellow:"#ffd166",
  red:"#ff4d6d", cyan:"#00c8ff", text:"#e8e8f0", muted:"#6b6b80", dim:"#3a3a50",
  purple:"#9b59b6", orange:"#ff8c42", pink:"#ff6b9d",
};

export const LIGHT = {
  bg:"#f4f4fb", surface:"#ffffff", card:"#f0f0fa", border:"#ddddf0",
  accent:"#6c63ff", glow:"#6c63ff22", green:"#00b87a", yellow:"#e6a800",
  red:"#e03055", cyan:"#0099cc", text:"#1a1a2e", muted:"#7070a0", dim:"#c0c0e0",
  purple:"#7b4ea0", orange:"#e06c20", pink:"#d94f88",
};

// Default export — will be overridden at runtime via ThemeContext
export const C = DARK;

export const S = {
  card:    { background:"#16161f", border:"1px solid #1e1e2e", borderRadius:16, padding:24 },
  label:   { fontSize:11, fontWeight:600, letterSpacing:"0.12em", color:"#6c63ff", textTransform:"uppercase", marginBottom:12, display:"flex", alignItems:"center", gap:8 },
  textarea:{ width:"100%", background:"#111118", border:"1px solid #3a3a50", borderRadius:10, color:"#e8e8f0", padding:"14px 16px", fontSize:13, fontFamily:"'DM Mono',monospace", resize:"vertical", outline:"none", lineHeight:1.6, boxSizing:"border-box" },
  input:   { width:"100%", padding:"12px 16px", background:"#111118", border:"1px solid #3a3a50", borderRadius:10, color:"#e8e8f0", fontSize:13, fontFamily:"'DM Mono',monospace", outline:"none", boxSizing:"border-box" },
  tag:     { display:"inline-flex", alignItems:"center", gap:4, padding:"4px 10px", borderRadius:6, fontSize:12, margin:"3px", fontWeight:500 },
  spinner: { width:40, height:40, border:"3px solid #3a3a50", borderTop:"3px solid #6c63ff", borderRadius:"50%", margin:"0 auto 16px", animation:"spin 0.8s linear infinite" },
};

export const GLOBAL_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:ital,wght@0,300;0,400;0,500;1,300&display=swap');
  *{box-sizing:border-box;}body{margin:0;color:#e8e8f0;}
  input:focus,textarea:focus,select:focus{border-color:#6c63ff!important;outline:none;}
  button{transition:all .18s;} button:hover:not(:disabled){opacity:.88;transform:translateY(-1px);} button:disabled{cursor:not-allowed;opacity:.55;}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes floatUp{from{opacity:0;transform:translateY(28px)}to{opacity:1;transform:translateY(0)}}
  @keyframes fadeIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
  .auth-in{animation:floatUp .5s ease forwards;}
  .fade-in{animation:fadeIn .4s ease forwards;}
  .hcard:hover{border-color:#6c63ff55!important;box-shadow:0 8px 32px #6c63ff18!important;transition:all .2s;}
  ::-webkit-scrollbar{width:6px}::-webkit-scrollbar-track{background:#0a0a0f}::-webkit-scrollbar-thumb{background:#2a2a3e;border-radius:3px}
  .stat-card{background:linear-gradient(135deg,#16161f,#1a1a28);border:1px solid #2a2a40;border-radius:16px;padding:28px;text-align:center;transition:all .3s;}
  .stat-card:hover{transform:translateY(-4px);box-shadow:0 12px 40px #6c63ff22;}
  .feature-card{background:#16161f;border:1px solid #1e1e2e;border-radius:16px;padding:28px;transition:all .3s;position:relative;overflow:hidden;}
  .feature-card:hover{transform:translateY(-6px);box-shadow:0 16px 48px #00000060;border-color:#6c63ff44;}
  .feature-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:var(--feature-color,#6c63ff);}
  .testimonial-card{background:#16161f;border:1px solid #1e1e2e;border-radius:16px;padding:24px;transition:all .3s;}
  .testimonial-card:hover{transform:translateY(-3px);border-color:#6c63ff33;}
`;