const BASE = "/api";
const tok  = () => sessionStorage.getItem("riq_token");

// ✅ FIXED req function (no JSON crash)
async function req(path, opts = {}) {
  const t = tok();

  const res = await fetch(`${BASE}${path}`, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      ...(t ? { Authorization: `Bearer ${t}` } : {}),
      ...(opts.headers || {}),
    },
  });

  // ✅ IMPORTANT FIX
  const text = await res.text();

  let data;
  try {
    data = JSON.parse(text);
  } catch (e) {
    console.error("❌ Server returned non-JSON:", text);
    throw new Error("Server error: Invalid response (not JSON)");
  }

  if (!res.ok) {
    throw new Error(data.error || "Request failed.");
  }

  return data;
}

// ── AUTH ─────────────────────────────────────────
export const register        = (name,email,password,role) => req("/auth/register", {method:"POST",body:JSON.stringify({name,email,password,role})});
export const login           = (email,password)           => req("/auth/login",    {method:"POST",body:JSON.stringify({email,password})});
export const logout          = ()                         => req("/auth/logout",   {method:"POST"});

// ── PROFILE ──────────────────────────────────────
export const getProfile      = ()                         => req("/profile");
export const updateProfile   = (data)                     => req("/profile", {method:"PUT",body:JSON.stringify(data)});
export const saveResume      = (name,text)                => req("/profile/resumes", {method:"POST",body:JSON.stringify({name,text})});
export const deleteResume    = (id)                       => req(`/profile/resumes/${id}`, {method:"DELETE"});

// Photo upload (multipart)
export const uploadPhoto = async (file) => {
  const fd = new FormData();
  fd.append("photo", file);

  const t = tok();
  const res = await fetch(`${BASE}/profile/photo`, {
    method: "POST",
    headers: t ? { Authorization: `Bearer ${t}` } : {},
    body: fd,
  });

  const text = await res.text();

  let data;
  try {
    data = JSON.parse(text);
  } catch {
    console.error("❌ Upload response not JSON:", text);
    throw new Error("Upload failed");
  }

  if (!res.ok) throw new Error(data.error);
  return data;
};

// ── CORE FEATURES ────────────────────────────────
export const analyzeResume   = (resume,jobDescription) => req("/analyze", {method:"POST",body:JSON.stringify({resume,jobDescription})});
export const getJobs         = ()                      => req("/jobs");
export const matchJob        = (resume,roleId)         => req("/job-match", {method:"POST",body:JSON.stringify({resume,roleId})});

// ✅ CAREER RECOMMENDATIONS (WORKING)
export const getCareerRec    = (resume) => req("/career-recommendations", {
  method: "POST",
  body: JSON.stringify({ resume })
});

// ── ROADMAP ──────────────────────────────────────
export const getRoadmap      = (resume,targetRole,days) => req("/roadmap", {
  method:"POST",
  body:JSON.stringify({resume,targetRole,days})
});

// ── INTERVIEW ────────────────────────────────────
export const getInterviewQ   = (resume,jobRole) => req("/interview/generate", {
  method:"POST",
  body:JSON.stringify({resume,jobRole})
});

export const evalAnswer      = (question,answer,jobRole) => req("/interview/evaluate", {
  method:"POST",
  body:JSON.stringify({question,answer,jobRole})
});

// ── COVER LETTER ────────────────────────────────
export const getCoverLetter  = (resume,jobDescription,tone,userName) =>
  req("/cover-letter", {
    method:"POST",
    body:JSON.stringify({resume,jobDescription,tone,userName})
  });

// ── RESUME BUILDER ─────────────────────────────
export const enhanceSection  = (section,content,jobTitle) =>
  req("/resume-builder/enhance", {
    method:"POST",
    body:JSON.stringify({section,content,jobTitle})
  });

// ── HISTORY ─────────────────────────────────────
export const getHistory      = () => req("/history");
export const deleteHistory   = (id) => req(`/history/${id}`, {method:"DELETE"});

// ── RECRUITER ───────────────────────────────────
export const getCandidates   = () => req("/recruiter/candidates");

// ── ADMIN ───────────────────────────────────────
export const getAdminAnalytics = () => req("/admin/stats");
export const addJob            = (data) => req("/admin/jobs", {method:"POST",body:JSON.stringify(data)});
export const deleteJob         = (id)   => req(`/admin/jobs/${id}`, {method:"DELETE"});

// ── AI ASSISTANT ────────────────────────────────
export const chatWithAssistant = (messages) =>
  req("/assistant/chat", {
    method:"POST",
    body:JSON.stringify({messages})
  });