import { useState } from "react";
import { GLOBAL_CSS, C } from "./theme";
import LandingPage   from "./pages/Landing";
import AuthPage      from "./pages/Auth";
import Sidebar       from "./components/Sidebar";
import Dashboard     from "./pages/Dashboard";
import Analyzer      from "./pages/Analyzer";
import Insights      from "./pages/Insights";
import JobMatch      from "./pages/JobMatch";
import CareerAI      from "./pages/CareerAI";
import Roadmap       from "./pages/Roadmap";
import InterviewPrep from "./pages/InterviewPrep";
import Builder       from "./pages/Builder";
import CoverLetter   from "./pages/CoverLetter";
import History       from "./pages/History";
import Profile       from "./pages/Profile";
import Recruiter     from "./pages/Recruiter";
import AdminPanel    from "./pages/Admin";
import * as API      from "./api";
import AIAssistant   from "./components/AIAssistant";

export default function App() {
  const [screen, setScreen] = useState("landing"); // landing | auth | app
  const [user,   setUser]   = useState(null);
  const [page,   setPage]   = useState("dashboard");

  const handleAuth = (u) => { setUser(u); setScreen("app"); setPage("dashboard"); };
  const handleLogout = async () => {
    try { await API.logout(); } catch {}
    sessionStorage.removeItem("riq_token");
    setUser(null); setScreen("landing"); setPage("dashboard");
  };
  const goToAuth = () => setScreen("auth");

  if (screen === "landing") return <><style>{GLOBAL_CSS}</style><LandingPage onGetStarted={goToAuth}/></>;
  if (screen === "auth")    return <><style>{GLOBAL_CSS}</style><AuthPage onAuth={handleAuth} onBack={()=>setScreen("landing")}/></>;

  const PAGES = {
    dashboard:   <Dashboard user={user} setPage={setPage}/>,
    analyzer:    <Analyzer/>,
    insights:    <Insights/>,
    jobmatch:    <JobMatch/>,
    career:      <CareerAI/>,
    roadmap:     <Roadmap/>,
    interview:   <InterviewPrep/>,
    builder:     <Builder/>,
    coverletter: <CoverLetter user={user}/>,
    history:     <History setPage={setPage}/>,
    profile:     <Profile user={user} onUserUpdate={setUser}/>,
    recruiter:   <Recruiter/>,
    admin:       <AdminPanel/>,
  };

  return (
    <>
      <style>{GLOBAL_CSS}</style>
      <div style={{display:"flex",minHeight:"100vh",background:C.bg,fontFamily:"'DM Mono',monospace",color:C.text}}>
        <Sidebar page={page} setPage={setPage} user={user} onLogout={handleLogout}/>
        <main style={{marginLeft:230,flex:1,padding:"32px 36px",maxWidth:"calc(100vw - 230px)",overflowX:"hidden"}}>
          {PAGES[page] || PAGES["dashboard"]}
        </main>
      </div>
      <AIAssistant />
    </>
  );
}
