import { C, S } from "../theme";

export function ScoreRing({ score, label, color, size=90 }) {
  const r=36, circ=2*Math.PI*r, off=circ-(score/100)*circ;
  return (
    <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:"20px 16px",textAlign:"center"}}>
      <div style={{position:"relative",width:size,height:size,margin:"0 auto 10px"}}>
        <svg width={size} height={size} style={{transform:"rotate(-90deg)"}}>
          <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={C.dim} strokeWidth="6"/>
          <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth="6"
            strokeDasharray={circ} strokeDashoffset={off} strokeLinecap="round"
            style={{transition:"stroke-dashoffset 1s ease",filter:`drop-shadow(0 0 6px ${color})`}}/>
        </svg>
        <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*0.22,fontWeight:700,color,fontFamily:"'Syne',sans-serif"}}>{score}</div>
      </div>
      <div style={{fontSize:11,color:C.muted,textTransform:"uppercase",letterSpacing:"0.1em"}}>{label}</div>
    </div>
  );
}
export function Spinner({ text="Loading..." }) {
  return <div style={{textAlign:"center",padding:"60px 20px"}}><div style={S.spinner}/><div style={{color:C.muted,fontSize:14,fontFamily:"'Syne',sans-serif"}}>{text}</div></div>;
}
export function ErrorBanner({ msg }) {
  return msg ? <div style={{background:"#ff4d6d18",border:"1px solid #ff4d6d44",borderRadius:10,padding:"12px 18px",color:C.red,fontSize:13,marginBottom:16}}>⚠️ {msg}</div> : null;
}
export function SuccessBanner({ msg }) {
  return msg ? <div style={{background:"#00e5a018",border:"1px solid #00e5a044",borderRadius:10,padding:"12px 18px",color:C.green,fontSize:13,marginBottom:16}}>✅ {msg}</div> : null;
}
export function PrimaryBtn({ onClick, disabled, children, style={} }) {
  return <button onClick={onClick} disabled={disabled} style={{border:"none",borderRadius:11,color:"#fff",fontWeight:700,fontFamily:"'Syne',sans-serif",letterSpacing:"0.05em",cursor:"pointer",padding:"13px 28px",fontSize:14,background:`linear-gradient(135deg,${C.accent},#9b59b6)`,boxShadow:`0 4px 24px ${C.glow}`,...style}}>{children}</button>;
}
export function Badge({ children, color=C.accent }) {
  return <span style={{padding:"3px 10px",borderRadius:20,fontSize:11,fontWeight:600,background:`${color}20`,color,border:`1px solid ${color}40`}}>{children}</span>;
}
export function ProgressBar({ value, color=C.accent, height=6 }) {
  return <div style={{height,background:C.dim,borderRadius:height/2,overflow:"hidden"}}><div style={{height:"100%",width:`${Math.min(value,100)}%`,borderRadius:height/2,background:`linear-gradient(90deg,${color}88,${color})`,transition:"width .8s ease"}}/></div>;
}
export function PageHeader({ icon, title, subtitle }) {
  return <div style={{marginBottom:28}}><div style={{fontSize:24,fontWeight:800,fontFamily:"'Syne',sans-serif",color:C.text,display:"flex",alignItems:"center",gap:10}}><span>{icon}</span>{title}</div>{subtitle&&<div style={{fontSize:13,color:C.muted,marginTop:5}}>{subtitle}</div>}</div>;
}
export function SkillPill({ skill, found }) {
  return <span style={{...S.tag,background:found?"#00e5a015":"#ff4d6d15",color:found?C.green:C.red,border:`1px solid ${found?"#00e5a030":"#ff4d6d30"}`}}>{found?"✓":"✗"} {skill}</span>;
}
