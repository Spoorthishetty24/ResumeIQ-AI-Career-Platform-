import { useState } from "react";
import { C, S } from "../theme";
import { PageHeader, Spinner, ErrorBanner, PrimaryBtn, Badge } from "../components/Shared";
import * as API from "../api";

export default function Roadmap() {
  const [resume,     setResume]     = useState("");
  const [targetRole, setTargetRole] = useState("");
  const [days,       setDays]       = useState(30);
  const [roadmap,    setRoadmap]    = useState(null);
  const [loading,    setLoading]    = useState(false);
  const [error,      setError]      = useState("");

  const generate = async () => {
    if (!resume.trim()||!targetRole.trim()) { setError("Resume and target role required."); return; }
    setError(""); setLoading(true); setRoadmap(null);
    try { setRoadmap(await API.getRoadmap(resume,targetRole,days)); }
    catch(ex){ setError(ex.message); }
    finally { setLoading(false); }
  };

  return (
    <div>
      <PageHeader icon="🗺️" title="Learning Roadmap Generator" subtitle="Get a day-by-day personalised study plan with projects and course recommendations"/>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:24,marginBottom:24}}>
        <div style={S.card} className="hcard">
          <div style={S.label}>📋 Your Resume</div>
          <textarea style={{...S.textarea,minHeight:200}} placeholder="Paste your resume here..." value={resume} onChange={e=>setResume(e.target.value)}/>
        </div>
        <div style={S.card} className="hcard">
          <div style={S.label}>🎯 Target Role</div>
          <input style={{...S.input,marginBottom:20}} placeholder="e.g. ML Engineer, Full Stack Developer..." value={targetRole} onChange={e=>setTargetRole(e.target.value)}/>
          <div style={S.label}>⏱️ Learning Duration</div>
          <div style={{display:"flex",gap:10}}>
            {[30,60,90].map(d=>(
              <button key={d} onClick={()=>setDays(d)} style={{flex:1,padding:"12px",borderRadius:10,border:`1px solid ${days===d?C.accent:C.dim}`,background:days===d?`${C.accent}22`:"transparent",color:days===d?C.accent:C.muted,fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"'Syne',sans-serif"}}>
                {d} Days
              </button>
            ))}
          </div>
          <div style={{marginTop:14,padding:"10px 14px",background:`${C.cyan}10`,borderRadius:8,fontSize:12,color:C.muted}}>
            💡 Daily commitment: ~{days===30?"2-3 hrs":days===60?"1.5-2 hrs":"1-1.5 hrs"}/day
          </div>
        </div>
      </div>
      <ErrorBanner msg={error}/>
      <PrimaryBtn onClick={generate} disabled={loading} style={{width:"100%",padding:16,fontSize:15,marginBottom:24}}>
        {loading?"⏳ Building Your Roadmap...":"🗺️ Generate Learning Roadmap"}
      </PrimaryBtn>
      {loading&&<Spinner text="AI is building your personalised learning plan..."/>}

      {roadmap&&!loading&&(
        <div className="fade-in">
          {/* Header */}
          <div style={{...S.card,marginBottom:24,background:`linear-gradient(135deg,${C.accent}15,${C.cyan}08)`,borderTop:`3px solid ${C.accent}`}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:12,marginBottom:12}}>
              <div>
                <div style={{fontSize:11,color:C.accent,fontWeight:600,marginBottom:4,letterSpacing:"0.1em"}}>{days}-DAY ROADMAP TO</div>
                <div style={{fontSize:20,fontWeight:800,fontFamily:"'Syne',sans-serif",color:C.text}}>{targetRole}</div>
              </div>
              <div style={{textAlign:"right"}}>
                <Badge color={C.cyan}>📅 {roadmap.daily_commitment}</Badge>
              </div>
            </div>
            <p style={{fontSize:14,color:C.text,lineHeight:1.7,margin:0}}>{roadmap.final_outcome}</p>

            {/* ✅ FIXED: certifications is array of objects, render c.name */}
            {roadmap.certifications?.length>0&&(
              <div style={{marginTop:12,display:"flex",gap:8,flexWrap:"wrap"}}>
                <span style={{fontSize:11,color:C.muted}}>🏆 Target Certs:</span>
                {roadmap.certifications.map((c,i)=>(
                  <Badge key={i} color={C.yellow}>
                    {typeof c === "object" ? c.name : c}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Weeks */}
          <div style={S.label}>📅 Weekly Breakdown</div>
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            {roadmap.weeks?.map((w,i)=>(
              <div key={i} style={{...S.card,borderLeft:`4px solid ${[C.accent,C.cyan,C.green,C.yellow][i%4]}`}} className="hcard">
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
                  <div style={{display:"flex",alignItems:"center",gap:12}}>
                    <div style={{width:40,height:40,borderRadius:10,background:`${[C.accent,C.cyan,C.green,C.yellow][i%4]}22`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,fontWeight:800,color:[C.accent,C.cyan,C.green,C.yellow][i%4],fontFamily:"'Syne',sans-serif"}}>W{w.week}</div>
                    <div>
                      <div style={{fontSize:15,fontWeight:700,fontFamily:"'Syne',sans-serif",color:C.text}}>{w.theme}</div>
                      <div style={{fontSize:11,color:C.muted,marginTop:2}}>Week {w.week}</div>
                    </div>
                  </div>
                </div>

                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:16}}>
                  <div>
                    <div style={{fontSize:10,color:C.green,fontWeight:600,marginBottom:6}}>🎯 GOALS</div>
                    {w.goals?.map((g,j)=><div key={j} style={{fontSize:12,color:C.muted,padding:"3px 0",lineHeight:1.5}}>▸ {g}</div>)}
                    {/* fallback for skills field */}
                    {!w.goals&&w.skills?.map((g,j)=><div key={j} style={{fontSize:12,color:C.muted,padding:"3px 0",lineHeight:1.5}}>▸ {g}</div>)}
                  </div>
                  <div>
                    <div style={{fontSize:10,color:C.cyan,fontWeight:600,marginBottom:6}}>📋 TASKS</div>
                    {w.tasks?.map((t,j)=><div key={j} style={{fontSize:12,color:C.muted,padding:"3px 0",lineHeight:1.5}}>▸ {t}</div>)}
                    {/* fallback for dailyGoal field */}
                    {!w.tasks&&w.dailyGoal&&<div style={{fontSize:12,color:C.muted,padding:"3px 0",lineHeight:1.5}}>▸ {w.dailyGoal}</div>}
                  </div>
                  <div>
                    <div style={{fontSize:10,color:C.yellow,fontWeight:600,marginBottom:6}}>🎓 COURSES</div>
                    {w.courses?.map((c,j)=>(
                      <div key={j} style={{fontSize:11,color:C.muted,padding:"3px 0",lineHeight:1.5}}>
                        {/* ✅ FIXED: safely render course fields */}
                        <span style={{color:C.text,fontWeight:500}}>{typeof c === "object" ? c.name : c}</span>
                        {typeof c === "object" && <span style={{color:C.dim}}> · {c.platform}{c.duration ? ` · ${c.duration}` : ""}</span>}
                      </div>
                    ))}
                  </div>
                </div>

                <div style={{marginTop:12,padding:"10px 14px",background:`${C.purple}12`,border:`1px solid ${C.purple}25`,borderRadius:8}}>
                  <span style={{fontSize:11,color:C.purple,fontWeight:600}}>🚀 MINI PROJECT: </span>
                  <span style={{fontSize:12,color:C.text}}>{w.project || w.miniProject}</span>
                </div>

                {/* milestone */}
                {w.milestone&&(
                  <div style={{marginTop:8,padding:"8px 14px",background:`${C.green}10`,border:`1px solid ${C.green}25`,borderRadius:8}}>
                    <span style={{fontSize:11,color:C.green,fontWeight:600}}>🏁 MILESTONE: </span>
                    <span style={{fontSize:12,color:C.text}}>{w.milestone}</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Success Metrics */}
          {roadmap.successMetrics?.length>0&&(
            <div style={{...S.card,marginTop:24}}>
              <div style={S.label}>✅ Success Metrics</div>
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {roadmap.successMetrics.map((m,i)=>(
                  <div key={i} style={{fontSize:13,color:C.muted,padding:"6px 0",borderBottom:`1px solid ${C.border}`}}>✔ {m}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}