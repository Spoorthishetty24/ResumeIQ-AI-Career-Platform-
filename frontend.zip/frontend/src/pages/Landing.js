import { C } from "../theme";
const FEATURES=[{icon:"🔍",title:"Resume Analyzer",desc:"ATS score, skill extraction, keyword analysis & AI feedback.",color:"#6c63ff"},{icon:"📈",title:"Visual Insights",desc:"Pie, bar & radar charts showing skill breakdown and job match.",color:"#00c8ff"},{icon:"🎯",title:"Job Matching",desc:"Match resume to 8+ roles. See match %, gaps and learning topics.",color:"#00e5a0"},{icon:"🌟",title:"Career AI",desc:"AI recommends your top 3 best-fit roles with salary ranges.",color:"#ffd166"},{icon:"🗺️",title:"Learning Roadmap",desc:"30/60/90 day plans with weekly tasks, projects and courses.",color:"#9b59b6"},{icon:"🎤",title:"Mock Interview",desc:"5 AI questions, type answers, get feedback with confidence score.",color:"#ff8c42"},{icon:"✏️",title:"Resume Builder",desc:"Section-by-section editor with AI enhancement.",color:"#ff6b9d"},{icon:"📝",title:"Cover Letter",desc:"Generate tailored cover letters in 5 tones instantly.",color:"#ff4d6d"},{icon:"👨‍💼",title:"Recruiter Portal",desc:"Browse candidates, filter by ATS score and skills.",color:"#00c8ff"},{icon:"🛠️",title:"Admin Panel",desc:"Manage job roles, analytics and skill gap monitoring.",color:"#6b6b80"}];
const STATS=[{icon:"📄",v:"10,000+",l:"Resumes Analyzed",c:"#6c63ff"},{icon:"🎯",v:"94%",l:"Interview Success Rate",c:"#00e5a0"},{icon:"👥",v:"5,000+",l:"Active Users",c:"#00c8ff"},{icon:"🏆",v:"4.9/5",l:"User Rating",c:"#ffd166"}];
const TESTS=[{n:"Priya Sharma",r:"Software Engineer at Infosys",i:"PS",t:"ResumeIQ boosted my ATS score from 42 to 87! Got 3 interview calls within a week.",s:5},{n:"Rahul Verma",r:"Data Analyst at TCS",i:"RV",t:"The career recommendation told me I was 82% suitable for Data Analyst. Landed my dream job in 2 months!",s:5},{n:"Anjali Patel",r:"ML Engineer at Wipro",i:"AP",t:"The mock interview feature is incredible. Cover letter generator saved me hours.",s:5},{n:"Karthik Nair",r:"HR at HCL",i:"KN",t:"As a recruiter the candidate dashboard saves me so much time. Filter by ATS score instantly.",s:5}];
export default function LandingPage({ onGetStarted }) {
  return(
    <div style={{background:"#0a0a0f",color:"#e8e8f0",minHeight:"100vh",fontFamily:"'Segoe UI',sans-serif"}}>
      <nav style={{position:"sticky",top:0,zIndex:1000,background:"#0a0a0fee",backdropFilter:"blur(12px)",borderBottom:"1px solid #1e1e2e",padding:"16px 0"}}>
        <div className="container d-flex justify-content-between align-items-center">
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{width:38,height:38,borderRadius:10,background:"linear-gradient(135deg,#6c63ff,#00c8ff)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>📄</div>
            <span style={{fontSize:20,fontWeight:800,fontFamily:"'Syne',sans-serif",background:"linear-gradient(135deg,#e8e8f0,#6c63ff)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>ResumeIQ</span>
          </div>
          <div style={{display:"flex",gap:10}}>
            <button onClick={onGetStarted} style={{padding:"8px 18px",background:"transparent",border:"1px solid #3a3a50",borderRadius:9,color:"#6b6b80",fontSize:13,cursor:"pointer",fontFamily:"'Syne',sans-serif",fontWeight:600}}>Sign In</button>
            <button onClick={onGetStarted} style={{padding:"8px 22px",background:"linear-gradient(135deg,#6c63ff,#9b59b6)",border:"none",borderRadius:9,color:"#fff",fontSize:13,cursor:"pointer",fontFamily:"'Syne',sans-serif",fontWeight:700,boxShadow:"0 4px 20px #6c63ff33"}}>Get Started Free →</button>
          </div>
        </div>
      </nav>
      <section style={{padding:"90px 0 70px",position:"relative",overflow:"hidden",background:"linear-gradient(135deg,#0a0a0f 0%,#0f0f20 50%,#0a0a0f 100%)"}}>
        <div style={{position:"absolute",width:700,height:700,borderRadius:"50%",background:"radial-gradient(circle,#6c63ff12,transparent 70%)",top:-200,left:-200,pointerEvents:"none"}}/>
        <div style={{position:"absolute",width:500,height:500,borderRadius:"50%",background:"radial-gradient(circle,#00c8ff10,transparent 70%)",bottom:-100,right:-100,pointerEvents:"none"}}/>
        <div className="container text-center" style={{position:"relative",zIndex:1}}>
          <div style={{display:"inline-block",padding:"6px 18px",borderRadius:20,background:"#6c63ff20",border:"1px solid #6c63ff44",color:"#6c63ff",fontSize:12,fontWeight:600,letterSpacing:"0.1em",marginBottom:24}}>🚀 AI-POWERED CAREER PLATFORM — 10 FEATURES</div>
          <h1 style={{fontSize:"clamp(34px,5vw,62px)",fontWeight:800,fontFamily:"'Syne',sans-serif",marginBottom:20,lineHeight:1.15}}>Land Your Dream Job with<br/><span style={{background:"linear-gradient(135deg,#6c63ff,#00c8ff)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>AI-Powered Resume Intelligence</span></h1>
          <p style={{fontSize:17,color:"#6b6b80",maxWidth:580,margin:"0 auto 36px",lineHeight:1.7}}>Analyze, optimize, and supercharge your resume. Get ATS scores, skill gap reports, career roadmaps, mock interview practice and more — all in one platform.</p>
          <div style={{display:"flex",gap:14,justifyContent:"center",flexWrap:"wrap",marginBottom:24}}>
            <button onClick={onGetStarted} style={{padding:"16px 36px",background:"linear-gradient(135deg,#6c63ff,#9b59b6)",border:"none",borderRadius:12,color:"#fff",fontSize:16,fontWeight:700,cursor:"pointer",fontFamily:"'Syne',sans-serif",boxShadow:"0 6px 30px #6c63ff33"}}>📄 Analyze My Resume Free →</button>
            <button onClick={onGetStarted} style={{padding:"16px 28px",background:"transparent",border:"1px solid #3a3a50",borderRadius:12,color:"#6b6b80",fontSize:15,cursor:"pointer",fontFamily:"'Syne',sans-serif"}}>Watch Demo ▶</button>
          </div>
          <div style={{display:"flex",gap:20,justifyContent:"center",flexWrap:"wrap"}}>
            {["✅ Free to use","✅ No credit card","✅ Instant results","✅ 10 AI features"].map(t=><span key={t} style={{fontSize:12,color:"#6b6b80"}}>{t}</span>)}
          </div>
        </div>
      </section>
      <section style={{padding:"50px 0",background:"#111118",borderTop:"1px solid #1e1e2e",borderBottom:"1px solid #1e1e2e"}}>
        <div className="container"><div className="row g-4">{STATS.map(s=><div className="col-6 col-md-3" key={s.l}><div className="stat-card"><div style={{fontSize:30,marginBottom:6}}>{s.icon}</div><div style={{fontSize:26,fontWeight:800,color:s.c,fontFamily:"'Syne',sans-serif",marginBottom:4}}>{s.v}</div><div style={{fontSize:12,color:"#6b6b80"}}>{s.l}</div></div></div>)}</div></div>
      </section>
      <section style={{padding:"70px 0"}}>
        <div className="container">
          <div className="text-center mb-5"><div style={{fontSize:12,color:"#6c63ff",fontWeight:600,letterSpacing:"0.15em",marginBottom:12}}>EVERYTHING YOU NEED</div><h2 style={{fontSize:"clamp(24px,4vw,40px)",fontWeight:800,fontFamily:"'Syne',sans-serif",marginBottom:12}}>10 Powerful AI Features</h2><p style={{fontSize:15,color:"#6b6b80",maxWidth:480,margin:"0 auto"}}>One platform. Every career tool you need to land your dream job.</p></div>
          <div className="row g-4">{FEATURES.map((f,i)=><div className="col-12 col-md-6 col-lg-4" key={i}><div className="feature-card h-100" style={{"--feature-color":f.color}}><div style={{fontSize:28,marginBottom:10}}>{f.icon}</div><h5 style={{fontWeight:700,fontFamily:"'Syne',sans-serif",color:"#e8e8f0",marginBottom:6}}>{f.title}</h5><p style={{fontSize:13,color:"#6b6b80",lineHeight:1.7,margin:0}}>{f.desc}</p></div></div>)}</div>
        </div>
      </section>
      <section style={{padding:"60px 0",background:"#111118",borderTop:"1px solid #1e1e2e",borderBottom:"1px solid #1e1e2e"}}>
        <div className="container">
          <div className="text-center mb-4"><h2 style={{fontSize:"clamp(22px,3vw,36px)",fontWeight:800,fontFamily:"'Syne',sans-serif"}}>How It Works</h2></div>
          <div className="row g-4">{[{step:"01",title:"Upload Resume",desc:"Upload PDF/DOCX or paste text.",icon:"📤"},{step:"02",title:"AI Analysis",desc:"Claude AI extracts skills and scores.",icon:"🤖"},{step:"03",title:"Get Insights",desc:"Charts, scores & personalised roadmap.",icon:"📊"},{step:"04",title:"Land the Job",desc:"Practice interviews, apply with confidence.",icon:"🎉"}].map((s,i)=><div className="col-6 col-md-3" key={i}><div style={{textAlign:"center",padding:"16px 8px"}}><div style={{width:52,height:52,borderRadius:"50%",background:"#6c63ff22",border:"2px solid #6c63ff44",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,margin:"0 auto 12px"}}>{s.icon}</div><div style={{fontSize:10,color:"#6c63ff",fontWeight:700,letterSpacing:"0.1em",marginBottom:4}}>STEP {s.step}</div><div style={{fontSize:14,fontWeight:700,fontFamily:"'Syne',sans-serif",marginBottom:6}}>{s.title}</div><div style={{fontSize:12,color:"#6b6b80",lineHeight:1.6}}>{s.desc}</div></div></div>)}</div>
        </div>
      </section>
      <section style={{padding:"70px 0"}}>
        <div className="container">
          <div className="text-center mb-4"><h2 style={{fontSize:"clamp(22px,3vw,36px)",fontWeight:800,fontFamily:"'Syne',sans-serif"}}>What Our Users Say</h2></div>
          <div className="row g-4">{TESTS.map((t,i)=><div className="col-12 col-md-6" key={i}><div className="testimonial-card h-100"><div style={{color:"#ffd166",fontSize:16,marginBottom:10}}>{"★".repeat(t.s)}</div><p style={{fontSize:14,color:"#e8e8f0",lineHeight:1.8,marginBottom:14,fontStyle:"italic"}}>"{t.t}"</p><div style={{display:"flex",alignItems:"center",gap:10}}><div style={{width:38,height:38,borderRadius:"50%",background:"linear-gradient(135deg,#6c63ff,#00c8ff)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:700,color:"#fff"}}>{t.i}</div><div><div style={{fontSize:13,fontWeight:600}}>{t.n}</div><div style={{fontSize:10,color:"#6b6b80"}}>{t.r}</div></div></div></div></div>)}</div>
        </div>
      </section>
      <section style={{padding:"70px 0",background:"linear-gradient(135deg,#6c63ff18,#00c8ff0a)",borderTop:"1px solid #6c63ff22"}}>
        <div className="container text-center">
          <h2 style={{fontSize:"clamp(24px,4vw,42px)",fontWeight:800,fontFamily:"'Syne',sans-serif",marginBottom:16}}>Ready to Supercharge Your Career?</h2>
          <p style={{fontSize:15,color:"#6b6b80",marginBottom:28,maxWidth:460,margin:"0 auto 28px"}}>Join 5,000+ professionals who've landed better jobs with ResumeIQ. Completely free.</p>
          <button onClick={onGetStarted} style={{padding:"16px 40px",background:"linear-gradient(135deg,#6c63ff,#9b59b6)",border:"none",borderRadius:14,color:"#fff",fontSize:16,fontWeight:700,cursor:"pointer",fontFamily:"'Syne',sans-serif",boxShadow:"0 8px 40px #6c63ff33"}}>🚀 Start Analyzing My Resume →</button>
        </div>
      </section>
      <footer style={{padding:"24px 0",borderTop:"1px solid #1e1e2e",background:"#111118"}}>
        <div className="container d-flex justify-content-between align-items-center flex-wrap gap-3">
          <div style={{fontSize:12,color:"#6b6b80"}}>© 2025 ResumeIQ — AI Career Platform. Built with Claude AI.</div>
          <div style={{display:"flex",gap:14}}>{["Privacy","Terms","Contact"].map(l=><span key={l} style={{fontSize:11,color:"#3a3a50",cursor:"pointer"}}>{l}</span>)}</div>
        </div>
      </footer>
    </div>
  );
}
