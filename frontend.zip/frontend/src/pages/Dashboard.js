import { useEffect, useState } from "react";
import { C, S } from "../theme";
import { ScoreRing, ProgressBar, Badge } from "../components/Shared";
import * as API from "../api";

export default function Dashboard({ user, setPage }) {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    API.getHistory().then(d => { setHistory(d.history || []); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const latest = history[0];
  const avg    = key => history.length ? Math.round(history.reduce((s, h) => s + (h[key] || 0), 0) / history.length) : 0;

  const FEATURES = [
    { id: "analyzer",    icon: "🔍", title: "Resume Analyzer",  desc: "Get ATS score, skill gap & AI feedback",  color: C.accent  },
    { id: "builder",     icon: "✏️",  title: "Resume Builder",   desc: "Write & enhance your resume sections",    color: C.cyan    },
    { id: "coverletter", icon: "📝", title: "Cover Letter",     desc: "Generate tailored cover letters with AI",  color: C.green   },
    { id: "interview",   icon: "🎯", title: "Interview Prep",   desc: "Practice Q&A based on your resume",       color: C.yellow  },
    { id: "roadmap",     icon: "🗺️",  title: "Career Roadmap",   desc: "Get a personalized career growth plan",   color: C.purple  },
    { id: "history",     icon: "📋", title: "History",          desc: "View all your past resume analyses",      color: C.orange  },
  ];

  return (
    <div>
      {/* Welcome banner */}
      <div style={{
        background: `linear-gradient(135deg, ${C.accent}22 0%, ${C.cyan}11 100%)`,
        border: `1px solid ${C.accent}33`, borderRadius: 18, padding: "28px 32px",
        marginBottom: 28, position: "relative", overflow: "hidden",
      }}>
        <div style={{ position: "absolute", right: -20, top: -20, width: 200, height: 200, borderRadius: "50%", background: `radial-gradient(circle,${C.accent}18,transparent 70%)`, pointerEvents: "none" }} />
        <div style={{ fontSize: 13, color: C.accent, fontWeight: 600, marginBottom: 6, letterSpacing: "0.1em" }}>WELCOME BACK</div>
        <div style={{ fontSize: 26, fontWeight: 800, fontFamily: "'Syne',sans-serif", color: C.text }}>
          Hey, {user?.name?.split(" ")[0]} 👋
        </div>
        <div style={{ fontSize: 14, color: C.muted, marginTop: 6 }}>
          {history.length === 0
            ? "Start by analyzing your resume to get personalized AI feedback."
            : `You've completed ${history.length}/10 analyses. ${history.length >= 10 ? "Limit reached — new analyses replace the oldest." : "Keep improving!"}`}
        </div>
        {history.length === 0 && (
          <button onClick={() => setPage("analyzer")} style={{
            marginTop: 16, padding: "10px 22px",
            background: `linear-gradient(135deg,${C.accent},#9b59b6)`,
            border: "none", borderRadius: 10, color: "#fff",
            fontSize: 13, fontWeight: 700, fontFamily: "'Syne',sans-serif",
            cursor: "pointer", boxShadow: `0 4px 20px ${C.glow}`,
          }}>🔍 Analyze My Resume →</button>
        )}
      </div>

      {/* Stats row */}
      {history.length > 0 && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 28 }}>
          <ScoreRing score={avg("ats_score")}     label="Avg ATS Score"  color={avg("ats_score") >= 70 ? C.green : avg("ats_score") >= 50 ? C.yellow : C.red} />
          <ScoreRing score={avg("quality_score")} label="Avg Quality"    color={C.cyan}   />
          <ScoreRing score={avg("impact_score")}  label="Avg Impact"     color={C.yellow} />
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, padding: "20px 16px", textAlign: "center" }}>
            <div style={{ fontSize: 38, fontWeight: 700, color: C.purple, fontFamily: "'Syne',sans-serif", marginBottom: 8 }}>{history.length}</div>
            <div style={{ fontSize: 11, color: C.muted, textTransform: "uppercase", letterSpacing: "0.1em" }}>Total Analyses</div>
          </div>
        </div>
      )}

      {/* Latest result */}
      {latest && (
        <div style={{ ...S.card, marginBottom: 28 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <div style={S.sectionTitle}>📊 Latest Analysis</div>
            <Badge color={C.muted}>{new Date(latest.date).toLocaleDateString()}</Badge>
          </div>
          <p style={{ fontSize: 13, color: C.muted, lineHeight: 1.7, margin: "0 0 20px" }}>{latest.summary}</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16 }}>
            {[
              { label: "ATS Compatibility", val: latest.ats_score, color: C.green },
              { label: "Content Quality",   val: latest.quality_score, color: C.cyan },
              { label: "Impact Score",      val: latest.impact_score, color: C.yellow },
            ].map(({ label, val, color }) => (
              <div key={label}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: C.muted, marginBottom: 6 }}>
                  <span>{label}</span><span style={{ color }}>{val}%</span>
                </div>
                <ProgressBar value={val} color={color} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Feature cards */}
      <div style={S.sectionTitle}>🚀 What Would You Like To Do?</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16 }}>
        {FEATURES.map(f => (
          <div key={f.id} className="hcard" onClick={() => setPage(f.id)} style={{
            ...S.card, cursor: "pointer", position: "relative", overflow: "hidden",
            borderTop: `3px solid ${f.color}`,
          }}>
            <div style={{ fontSize: 28, marginBottom: 10 }}>{f.icon}</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: C.text, fontFamily: "'Syne',sans-serif", marginBottom: 6 }}>{f.title}</div>
            <div style={{ fontSize: 12, color: C.muted, lineHeight: 1.5 }}>{f.desc}</div>
            <div style={{ position: "absolute", top: 16, right: 16, fontSize: 18, opacity: 0.3 }}>→</div>
          </div>
        ))}
      </div>
    </div>
  );
}
