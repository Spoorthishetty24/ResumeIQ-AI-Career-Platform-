import { useState } from "react";
import { C, S } from "../theme";
import { ErrorBanner, PrimaryBtn, Spinner } from "../components/Shared";
import * as API from "../api";

const TONES = ["professional", "enthusiastic", "creative", "formal", "conversational"];

export default function CoverLetter({ user }) {
  const [resume,  setResume]  = useState("");
  const [jobDesc, setJobDesc] = useState("");
  const [tone,    setTone]    = useState("professional");
  const [letter,  setLetter]  = useState("");
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");
  const [copied,  setCopied]  = useState(false);

  const generate = async () => {
    if (!resume.trim() || !jobDesc.trim()) { setError("Both resume and job description are required."); return; }
    setError(""); setLoading(true); setLetter("");
    try {
      const res = await API.getCoverLetter(resume, jobDesc, tone, user?.name);
      setLetter(res.coverLetter);
    } catch (ex) { setError(ex.message); }
    finally { setLoading(false); }
  };

  const copy = () => { navigator.clipboard.writeText(letter); setCopied(true); setTimeout(() => setCopied(false), 2000); };

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 22, fontWeight: 800, fontFamily: "'Syne',sans-serif", color: C.text }}>📝 Cover Letter Generator</div>
        <div style={{ fontSize: 13, color: C.muted, marginTop: 4 }}>Generate a personalized, job-specific cover letter in seconds</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 24 }}>
        <div style={S.card} className="hcard">
          <div style={S.label}><span>📋</span> Your Resume</div>
          <textarea style={{ ...S.textarea, minHeight: 200 }} placeholder="Paste your resume text here..." value={resume} onChange={e => setResume(e.target.value)} />
        </div>
        <div style={S.card} className="hcard">
          <div style={S.label}><span>💼</span> Job Description</div>
          <textarea style={{ ...S.textarea, minHeight: 200 }} placeholder="Paste the job description here..." value={jobDesc} onChange={e => setJobDesc(e.target.value)} />
        </div>
      </div>

      {/* Tone selector */}
      <div style={{ ...S.card, marginBottom: 24 }}>
        <div style={S.label}>🎨 Writing Tone</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {TONES.map(t => (
            <button key={t} onClick={() => setTone(t)} style={{
              padding: "8px 20px", borderRadius: 20, cursor: "pointer", fontSize: 12,
              fontWeight: 600, textTransform: "capitalize", fontFamily: "'Syne',sans-serif",
              border: `1px solid ${tone === t ? C.accent : C.dim}`,
              background: tone === t ? `${C.accent}22` : "transparent",
              color: tone === t ? C.accent : C.muted,
            }}>{t}</button>
          ))}
        </div>
      </div>

      <ErrorBanner msg={error} />
      <PrimaryBtn onClick={generate} disabled={loading} style={{ width: "100%", padding: 16, fontSize: 15, marginBottom: 24 }}>
        {loading ? "⏳ Generating..." : "📝 Generate Cover Letter"}
      </PrimaryBtn>

      {loading && <Spinner text="AI is crafting your cover letter..." />}

      {letter && !loading && (
        <div className="fade-in" style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <div style={S.sectionTitle}>📄 Your Cover Letter</div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={copy} style={{ padding: "7px 16px", background: copied ? `${C.green}22` : `${C.accent}22`, border: `1px solid ${copied ? C.green : C.accent}44`, borderRadius: 8, color: copied ? C.green : C.accent, fontSize: 12, cursor: "pointer", fontFamily: "'DM Mono',monospace", fontWeight: 600 }}>
                {copied ? "✅ Copied!" : "📋 Copy"}
              </button>
              <button onClick={generate} style={{ padding: "7px 16px", background: `${C.purple}22`, border: `1px solid ${C.purple}44`, borderRadius: 8, color: C.purple, fontSize: 12, cursor: "pointer", fontFamily: "'DM Mono',monospace", fontWeight: 600 }}>
                🔄 Regenerate
              </button>
            </div>
          </div>
          <div style={{ background: C.surface, borderRadius: 12, padding: "24px 28px", fontSize: 14, color: C.text, lineHeight: 1.9, whiteSpace: "pre-wrap", border: `1px solid ${C.border}`, fontFamily: "Georgia, serif" }}>
            {letter}
          </div>
          <div style={{ marginTop: 16, padding: "10px 14px", background: `${C.cyan}12`, border: `1px solid ${C.cyan}30`, borderRadius: 8, fontSize: 12, color: C.muted }}>
            💡 <strong style={{ color: C.cyan }}>Tip:</strong> Review and personalize before sending. Add specific company details, names, and any achievements that weren't in your resume.
          </div>
        </div>
      )}
    </div>
  );
}
