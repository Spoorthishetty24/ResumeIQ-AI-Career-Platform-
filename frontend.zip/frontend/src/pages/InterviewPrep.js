import { useState } from "react";
import { C, S } from "../theme";
import { ErrorBanner, PrimaryBtn, Spinner, Badge } from "../components/Shared";
import * as API from "../api";

const TYPES = ["mixed", "behavioral", "technical", "situational"];
const DIFF_COLOR = { easy: C.green, medium: C.yellow, hard: C.red };
const CAT_COLOR  = { behavioral: C.accent, technical: C.cyan, situational: C.orange };

export default function InterviewPrep() {
  const [resume,   setResume]   = useState("");
  const [jobDesc,  setJobDesc]  = useState("");
  const [qType,    setQType]    = useState("mixed");
  const [questions,setQuestions]= useState([]);
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState("");
  const [expanded, setExpanded] = useState(null);
  const [answers,  setAnswers]  = useState({});

  const generate = async () => {
    if (!resume.trim()) { setError("Please provide your resume."); return; }
    setError(""); setLoading(true); setQuestions([]); setExpanded(null);
    try {
      const res = await API.getInterviewQ(resume, jobDesc, qType);
      setQuestions(res.questions || []);
    } catch (ex) { setError(ex.message); }
    finally { setLoading(false); }
  };

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 22, fontWeight: 800, fontFamily: "'Syne',sans-serif", color: C.text }}>🎯 Interview Prep</div>
        <div style={{ fontSize: 13, color: C.muted, marginTop: 4 }}>Get AI-generated interview questions with model answers tailored to your resume</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 24 }}>
        <div style={S.card} className="hcard">
          <div style={S.label}><span>📋</span> Your Resume</div>
          <textarea style={{ ...S.textarea, minHeight: 180 }} placeholder="Paste your resume here..." value={resume} onChange={e => setResume(e.target.value)} />
        </div>
        <div style={S.card} className="hcard">
          <div style={S.label}><span>💼</span> Job Description <span style={{ color: C.muted, fontWeight: 400, fontSize: 10, textTransform: "none", letterSpacing: 0 }}>(optional)</span></div>
          <textarea style={{ ...S.textarea, minHeight: 180 }} placeholder="Paste job description for targeted questions..." value={jobDesc} onChange={e => setJobDesc(e.target.value)} />
        </div>
      </div>

      {/* Question type */}
      <div style={{ ...S.card, marginBottom: 24 }}>
        <div style={S.label}>❓ Question Type</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {TYPES.map(t => (
            <button key={t} onClick={() => setQType(t)} style={{
              padding: "8px 20px", borderRadius: 20, cursor: "pointer", fontSize: 12, fontWeight: 600, textTransform: "capitalize", fontFamily: "'Syne',sans-serif",
              border: `1px solid ${qType === t ? C.accent : C.dim}`,
              background: qType === t ? `${C.accent}22` : "transparent",
              color: qType === t ? C.accent : C.muted,
            }}>{t}</button>
          ))}
        </div>
      </div>

      <ErrorBanner msg={error} />
      <PrimaryBtn onClick={generate} disabled={loading} style={{ width: "100%", padding: 16, fontSize: 15, marginBottom: 24 }}>
        {loading ? "⏳ Generating Questions..." : "🎯 Generate Interview Questions"}
      </PrimaryBtn>

      {loading && <Spinner text="AI is preparing your interview questions..." />}

      {questions.length > 0 && !loading && (
        <div className="fade-in">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div style={S.sectionTitle}>❓ {questions.length} Interview Questions</div>
            <div style={{ fontSize: 12, color: C.muted }}>Click any question to see model answer</div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {questions.map((q, i) => (
              <div key={q.id || i} style={{ ...S.card, cursor: "pointer" }} className="hcard" onClick={() => setExpanded(expanded === i ? null : i)}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
                      <Badge color={CAT_COLOR[q.category] || C.accent}>{q.category}</Badge>
                      <Badge color={DIFF_COLOR[q.difficulty] || C.muted}>{q.difficulty}</Badge>
                    </div>
                    <div style={{ fontSize: 14, color: C.text, fontWeight: 600, lineHeight: 1.5 }}>Q{i + 1}. {q.question}</div>
                    <div style={{ fontSize: 12, color: C.muted, marginTop: 8, fontStyle: "italic" }}>💡 {q.tip}</div>
                  </div>
                  <div style={{ fontSize: 18, color: C.muted, flexShrink: 0 }}>{expanded === i ? "▲" : "▼"}</div>
                </div>

                {expanded === i && (
                  <div className="fade-in" style={{ marginTop: 16, paddingTop: 16, borderTop: `1px solid ${C.border}` }}>
                    <div style={{ fontSize: 11, color: C.green, fontWeight: 600, marginBottom: 10, letterSpacing: "0.08em" }}>✅ MODEL ANSWER</div>
                    <div style={{ fontSize: 13, color: C.text, lineHeight: 1.8, background: C.surface, borderRadius: 10, padding: 16, marginBottom: 16 }}>
                      {q.sampleAnswer}
                    </div>
                    <div style={{ fontSize: 11, color: C.muted, marginBottom: 8, fontWeight: 600 }}>📝 YOUR PRACTICE ANSWER</div>
                    <textarea
                      style={{ ...S.textarea, minHeight: 100 }}
                      placeholder="Practice writing your answer here..."
                      value={answers[i] || ""}
                      onChange={e => { e.stopPropagation(); setAnswers(prev => ({ ...prev, [i]: e.target.value })); }}
                      onClick={e => e.stopPropagation()}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
